import{j as e,bZ as t}from"./index-CRY-iyFJ.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

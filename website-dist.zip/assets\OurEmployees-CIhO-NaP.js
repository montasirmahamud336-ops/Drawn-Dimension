import{j as e,bZ as t}from"./index-DK2_7Gs0.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

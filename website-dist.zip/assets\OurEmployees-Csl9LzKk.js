import{j as e,bZ as t}from"./index-CiSPa8Gj.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

import{b5 as c,j as e,w as m}from"./index-CRY-iyFJ.js";const p=({data:i})=>{const t=i??c.sections["trusted-logos"],r=t.logos.filter(a=>a.image_url);return r.length===0?null:e.jsxs("section",{id:"trusted-logos",className:"relative overflow-hidden py-12 md:py-16",children:[e.jsx("div",{className:"container-narrow relative z-10",children:e.jsxs("div",{className:"mx-auto mb-12 max-w-3xl text-center",children:[e.jsxs("span",{className:"inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-primary",children:[e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-primary animate-pulse"}),t.badge]}),e.jsx("h2",{className:"mt-5 text-3xl font-extrabold tracking-tight text-foreground md:text-4xl",children:t.title}),e.jsx("p",{className:"mt-4 text-base leading-relaxed text-muted-foreground md:text-lg",children:t.description})]})}),e.jsxs("div",{className:"relative",children:[e.jsx("div",{className:"pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-background to-transparent"}),e.jsx("div",{className:"pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-background to-transparent"}),e.jsx("div",{className:"overflow-hidden marquee-container group",children:e.jsx("div",{className:"marquee-track inline-flex items-center",style:{animationDuration:`${r.length*7}s`},children:[...r,...r].map((a,n)=>{const l=m(a.image_url),s=e.jsx("img",{src:l,alt:a.name,loading:n<r.length?"eager":"lazy",decoding:"async",onError:o=>{o.currentTarget.style.display="none"},className:"h-20 w-auto object-contain opacity-80 transition-opacity duration-300 hover:opacity-100 md:h-28"});return a.link?e.jsx("a",{href:a.link,target:"_blank",rel:"noreferrer",className:"inline-block px-6 md:px-8 shrink-0","aria-label":a.name,children:s},`${a.id}-${n}`):e.jsx("span",{className:"inline-block px-6 md:px-8 shrink-0",children:s},`${a.id}-${n}`)})})})]}),e.jsx("style",{children:`
        .marquee-track {
          animation: marqueeScroll linear infinite;
        }
        .marquee-container:hover .marquee-track {
          animation-play-state: paused;
        }
        @keyframes marqueeScroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
      `})]})};export{p as default};

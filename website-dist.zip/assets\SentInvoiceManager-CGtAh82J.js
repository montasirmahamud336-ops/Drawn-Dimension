import{g as Me,r as p,j as e,B as N,aM as Re,ad as Oe,L as M,E as Ue,am as w,aN as se,S as He,a1 as We,a2 as Ve,aO as je,I as W,aa as x}from"./index-DtKEOIAZ.js";import{C as _,a as I,e as $,b as k,c as S}from"./card-Y9LzTriH.js";import{C as qe}from"./checkbox-LsuztZg-.js";import{D as Je,a as Ye,b as Ze,c as Ge,e as Ke}from"./dialog-BYhEI-kr.js";import{I as V}from"./input-XPVt5Vnl.js";import{T as ve,a as ye,b as L,c as C,d as Ne,e as v}from"./table-CNDsojpR.js";import{T as we}from"./textarea-DNlr3q2R.js";import{T as Qe}from"./trash-2-DLeE51cN.js";import"./index-Dim1dTY-.js";import"./index-CDLl9Ing.js";import"./index-CTjQ1N3C.js";import"./tslib.es6-B2dMZmZB.js";const y=s=>s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;"),_e=s=>`BDT ${new Intl.NumberFormat("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2}).format(s)}`,Xe=s=>{const r=new Date(s);return Number.isNaN(r.getTime())?s:r.toLocaleDateString("en-BD",{year:"numeric",month:"long",day:"numeric"})},et=s=>{const r=(s==null?void 0:s.trim())||"";return!r||r.toLowerCase()==="no additional details"?null:r},tt=s=>{var b;const r=s.items.map((i,j)=>{var D;const u=y(((D=i.orderCode)==null?void 0:D.trim())||"Custom"),T=y(i.title),l=y(_e(i.amount)),F=et(i.description),B=F?`<span>${y(F)}</span>`:"";return`
        <tr>
          <td>${j+1}</td>
          <td>${u}</td>
          <td>
            <strong>${T}</strong>
            ${B}
          </td>
          <td class="amount">${l}</td>
        </tr>
      `}).join("");return`
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>${y(s.invoiceNumber)}</title>
        <style>
          :root {
            color-scheme: light;
            --ink: #0f172a;
            --muted: #64748b;
            --line: #dbe5f1;
            --soft: #f8fafc;
            --accent: #ef4444;
          }
          * { box-sizing: border-box; }
          body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--ink);
            background: #eef2f7;
          }
          .page {
            max-width: 920px;
            margin: 32px auto;
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: 22px;
            overflow: hidden;
            box-shadow: 0 18px 50px rgba(15, 23, 42, 0.08);
          }
          .toolbar {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: center;
            padding: 16px 24px;
            background: rgba(15, 23, 42, 0.95);
            color: #ffffff;
          }
          .toolbar button {
            border: 0;
            border-radius: 999px;
            padding: 10px 16px;
            background: #ffffff;
            color: var(--ink);
            font-weight: 600;
            cursor: pointer;
          }
          .hero {
            padding: 30px 32px 26px;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #ffffff;
          }
          .hero p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.72);
          }
          .hero h1 {
            margin: 0;
            font-size: 32px;
            line-height: 1.1;
          }
          .content {
            padding: 28px 32px 32px;
          }
          .meta {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 24px;
          }
          .meta-card {
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: var(--soft);
          }
          .meta-card p {
            margin: 0 0 6px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .meta-card h2 {
            margin: 0;
            font-size: 18px;
          }
          .meta-card .sub {
            margin-top: 8px;
            font-size: 14px;
            color: #475569;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 16px;
          }
          th, td {
            padding: 14px 12px;
            text-align: left;
            border-bottom: 1px solid var(--line);
            vertical-align: top;
          }
          th {
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
            background: var(--soft);
          }
          td strong {
            display: block;
            margin-bottom: 6px;
            font-size: 14px;
          }
          td span {
            display: block;
            font-size: 13px;
            line-height: 1.55;
            color: #475569;
          }
          td.amount {
            text-align: right;
            font-weight: 700;
            white-space: nowrap;
          }
          .notes {
            margin-top: 18px;
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: var(--soft);
          }
          .notes p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .notes div {
            font-size: 14px;
            line-height: 1.7;
            color: #334155;
            white-space: pre-wrap;
          }
          .total {
            margin-top: 20px;
            padding: 20px 24px;
            border-radius: 18px;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.08), rgba(15, 23, 42, 0.05));
            border: 1px solid rgba(239, 68, 68, 0.2);
            text-align: right;
          }
          .total p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .total h3 {
            margin: 0;
            font-size: 30px;
          }
          @media (max-width: 720px) {
            .page { margin: 0; border-radius: 0; }
            .toolbar, .hero, .content { padding-left: 18px; padding-right: 18px; }
            .meta { grid-template-columns: 1fr; }
            th, td { padding-left: 10px; padding-right: 10px; }
          }
          @media print {
            body { background: #ffffff; }
            .page {
              margin: 0;
              max-width: none;
              border: 0;
              border-radius: 0;
              box-shadow: none;
            }
            .toolbar { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="page">
          <div class="toolbar">
            <div>Use your browser print dialog to save this invoice as PDF.</div>
            <button type="button" onclick="window.print()">Print / Save PDF</button>
          </div>

          <section class="hero">
            <p>Employee Invoice</p>
            <h1>${y(s.monthLabel)}</h1>
          </section>

          <section class="content">
            <div class="meta">
              <div class="meta-card">
                <p>Invoice To</p>
                <h2>${y(s.employeeName)}</h2>
                <div class="sub">${y(s.employeeEmail)}</div>
              </div>
              <div class="meta-card">
                <p>Invoice Info</p>
                <h2>${y(s.invoiceNumber)}</h2>
                <div class="sub">Sent: ${y(Xe(s.sentAt))}</div>
              </div>
            </div>

            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Order</th>
                  <th>Work</th>
                  <th style="text-align:right;">Amount</th>
                </tr>
              </thead>
              <tbody>${r}</tbody>
            </table>

            ${(b=s.notes)!=null&&b.trim()?`
                  <div class="notes">
                    <p>Notes</p>
                    <div>${y(s.notes.trim())}</div>
                  </div>
                `:""}

            <div class="total">
              <p>Total</p>
              <h3>${y(_e(s.totalAmount))}</h3>
            </div>
          </section>
        </div>
        <script>
          window.addEventListener("load", function () {
            window.setTimeout(function () {
              try {
                window.print();
              } catch (error) {
                console.error(error);
              }
            }, 300);
          });
        <\/script>
      </body>
    </html>
  `},q=s=>{const r=window.open("","_blank","noopener,noreferrer,width=1100,height=900");if(!r)throw new Error("Popup blocked. Please allow popups to print or save the invoice.");r.document.open(),r.document.write(tt(s)),r.document.close()},Ie=()=>{const s=new Date;return`${s.getFullYear()}-${String(s.getMonth()+1).padStart(2,"0")}`},st=()=>({id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,title:"",description:"",amount:""}),Z=s=>{if(s==null)return null;const r=Number(String(s).replace(/,/g,"").trim());return!Number.isFinite(r)||r<0?null:Number(r.toFixed(2))},E=s=>`BDT ${new Intl.NumberFormat("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2}).format(s)}`,G=s=>{const[r,b]=s.split("-").map(Number);return!r||!b?s:new Date(Date.UTC(r,b-1,1)).toLocaleDateString("en-BD",{year:"numeric",month:"long",timeZone:"UTC"})},J=s=>{if(!s)return"-";const r=new Date(s);return Number.isNaN(r.getTime())?"-":r.toLocaleString("en-BD",{dateStyle:"medium",timeStyle:"short"})},Se=s=>{const r=(s==null?void 0:s.trim())||"";return!r||r.toLowerCase()==="no additional details"?null:r},Y=async(s,r)=>{if((s.headers.get("content-type")||"").includes("application/json")){const j=await s.json().catch(()=>null);if(j!=null&&j.message){const u=String(j.message);return u.includes("completed_at")&&u.includes("does not exist")?"Invoice migration is missing. Please run the latest Supabase migration first.":u.includes("employee_invoices")||u.includes("employee_invoice_line_items")?"Invoice tables are missing in the database. Please run the latest Supabase migration first.":u}}const i=await s.text().catch(()=>"");return i||r},rt=s=>s?s.assignments.filter(r=>!r.already_invoiced).map(r=>r.id):[],nt=(s,r,b)=>{const i=[],j=[],u=[];let T=0;return s&&s.assignments.forEach(l=>{r.includes(l.id)&&(i.push({orderCode:l.order_code,title:l.work_title,description:null,amount:l.payment_amount}),j.push({work_assignment_id:l.id}),T+=l.payment_amount)}),b.forEach((l,F)=>{if(!(l.title.trim()||l.description.trim()||l.amount.trim()))return;const D=l.title.trim(),A=Z(l.amount);if(!D||A===null||A<=0){u.push(F+1);return}i.push({orderCode:null,title:D,description:l.description.trim()||null,amount:A}),j.push({title:D,description:l.description.trim()||null,amount:A}),T+=A}),{printableItems:i,apiItems:j,totalAmount:T,invalidCustomItems:u}},ke=s=>({invoiceNumber:s.invoice.invoice_number,monthLabel:G(String(s.invoice.invoice_month).slice(0,7)),employeeName:s.invoice.employee_name,employeeEmail:s.invoice.employee_email,sentAt:s.invoice.sent_at,totalAmount:s.items.reduce((r,b)=>r+b.amount,0),notes:s.invoice.notes??null,items:s.items.map(r=>({orderCode:r.order_code,title:r.title,description:r.item_type==="custom"?Se(r.description):null,amount:r.amount}))}),ft=()=>{const s=Me(),[r,b]=p.useState(Ie),[i,j]=p.useState(G(Ie())),[u,T]=p.useState([]),[l,F]=p.useState([]),[B,D]=p.useState(!0),[A,Ce]=p.useState(""),[P,re]=p.useState(""),[R,ne]=p.useState([]),[K,O]=p.useState([]),[U,oe]=p.useState(""),[ae,ie]=p.useState(!1),[De,Q]=p.useState(null),[d,le]=p.useState(null),[$e,de]=p.useState(!1),[ce,me]=p.useState(null),[xe,pe]=p.useState(null),ue=u.filter(t=>`${t.employee_name} ${t.employee_email} ${t.profession??""}`.toLowerCase().includes(A.toLowerCase())),a=u.find(t=>t.employee_id===P)??null,h=nt(a,R,K),he=u.reduce((t,n)=>(t.assignmentCount+=n.assignment_count,t.totalAmount+=n.total_amount,t),{assignmentCount:0,totalAmount:0}),ge=t=>{ne(rt(t)),O([]),oe("")},H=async(t,n=P,o=!0)=>{var g;const c=W();if(!c){x.error("Session expired. Please login again.");return}D(!0);try{const m=await fetch(`${s}/employee-invoices/source?month=${encodeURIComponent(t)}`,{headers:{Authorization:`Bearer ${c}`}});if(!m.ok)throw new Error(await Y(m,"Failed to load invoice source"));const f=await m.json(),z=Array.isArray(f==null?void 0:f.employees)?f.employees:[],Le=Array.isArray(f==null?void 0:f.sent_invoices)?f.sent_invoices:[];T(z),F(Le),j(String((f==null?void 0:f.month_label)||G(t)));const ee=z.some(te=>te.employee_id===n)?n:((g=z[0])==null?void 0:g.employee_id)??"";if(re(ee),o||ee!==n){const te=z.find(Be=>Be.employee_id===ee)??null;ge(te)}}catch(m){console.error(m),x.error(m instanceof Error?m.message:"Failed to load invoice source")}finally{D(!1)}},fe=async t=>{const n=W();if(!n)return x.error("Session expired. Please login again."),null;const o=await fetch(`${s}/employee-invoices/${encodeURIComponent(t)}`,{headers:{Authorization:`Bearer ${n}`}});if(!o.ok)throw new Error(await Y(o,"Failed to load invoice details"));const c=await o.json();return{invoice:{...c.invoice,total_amount:Z(c.invoice.total_amount)??0},items:Array.isArray(c.items)?c.items.map(g=>({...g,amount:Z(g.amount)??0})):[]}};p.useEffect(()=>{H(r,P,!0)},[r]);const Ae=t=>{re(t.employee_id),ge(t)},Ee=(t,n)=>{ne(o=>n?o.includes(t)?o:[...o,t]:o.filter(c=>c!==t))},X=(t,n)=>{O(o=>o.map(c=>c.id===t?{...c,...n}:c))},Te=()=>{if(!a){x.error("Select an employee first");return}if(h.invalidCustomItems.length>0){x.error(`Please fix custom item ${h.invalidCustomItems.join(", ")}`);return}if(h.printableItems.length===0){x.error("Select at least one assignment or add one custom item");return}try{q({invoiceNumber:`DRAFT-${r.replace("-","")}-${a.employee_name.replace(/\s+/g,"-").toUpperCase()}`,monthLabel:i,employeeName:a.employee_name,employeeEmail:a.employee_email,sentAt:new Date().toISOString(),totalAmount:h.totalAmount,notes:U.trim()||null,items:h.printableItems})}catch(t){x.error(t instanceof Error?t.message:"Could not open invoice print window")}},ze=async()=>{var n,o,c;const t=W();if(!t){x.error("Session expired. Please login again.");return}if(!a){x.error("Select an employee first");return}if(h.invalidCustomItems.length>0){x.error(`Please fix custom item ${h.invalidCustomItems.join(", ")}`);return}if(h.apiItems.length===0){x.error("Select at least one assignment or add one custom item");return}ie(!0);try{const g=await fetch(`${s}/employee-invoices/send`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({employee_id:a.employee_id,invoice_month:r,notes:U.trim()||null,items:h.apiItems})});if(!g.ok)throw new Error(await Y(g,"Failed to send invoice"));const m=await g.json(),f={invoiceNumber:String(((n=m==null?void 0:m.invoice)==null?void 0:n.invoice_number)||""),monthLabel:String((m==null?void 0:m.month_label)||i),employeeName:a.employee_name,employeeEmail:a.employee_email,sentAt:String(((o=m==null?void 0:m.invoice)==null?void 0:o.sent_at)||new Date().toISOString()),totalAmount:Z((c=m==null?void 0:m.invoice)==null?void 0:c.total_amount)??h.totalAmount,notes:U.trim()||null,items:h.printableItems};x.success(`Invoice sent to ${a.employee_email}`);try{q(f)}catch(z){x.info(z instanceof Error?z.message:"Invoice sent. Popup could not be opened for printing.")}await H(r,a.employee_id,!0)}catch(g){console.error(g),x.error(g instanceof Error?g.message:"Failed to send invoice")}finally{ie(!1)}},Fe=async t=>{Q(t),de(!0);try{const n=await fe(t);if(!n)return;le(n)}catch(n){console.error(n),x.error(n instanceof Error?n.message:"Failed to load invoice"),Q(null)}finally{de(!1)}},Pe=async t=>{me(t);try{const n=await fe(t);if(!n)return;q(ke(n))}catch(n){console.error(n),x.error(n instanceof Error?n.message:"Could not open invoice print window")}finally{me(null)}},be=async t=>{const n=W();if(!n){x.error("Session expired. Please login again.");return}if(confirm(`Resend ${t.invoice_number} to ${t.employee_email}?`)){pe(t.id);try{const o=await fetch(`${s}/employee-invoices/${encodeURIComponent(t.id)}/resend`,{method:"POST",headers:{Authorization:`Bearer ${n}`}});if(!o.ok)throw new Error(await Y(o,"Failed to resend invoice"));x.success(`Invoice resent to ${t.employee_email}`),await H(r,P,!1)}catch(o){console.error(o),x.error(o instanceof Error?o.message:"Failed to resend invoice")}finally{pe(null)}}};return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl font-bold tracking-tight",children:"Sent Invoice"}),e.jsx("p",{className:"text-muted-foreground",children:"Review completed monthly work, remove or add line items, then email invoices to employees."})]}),e.jsxs("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-end",children:[e.jsxs("div",{className:"grid gap-2",children:[e.jsx("label",{htmlFor:"invoice-month",className:"text-sm font-medium",children:"Invoice Month"}),e.jsx(V,{id:"invoice-month",type:"month",value:r,onChange:t=>b(t.target.value),className:"min-w-[220px]"})]}),e.jsxs(N,{type:"button",variant:"outline",className:"gap-2",onClick:()=>H(r,P,!1),children:[e.jsx(Re,{className:"h-4 w-4"}),"Refresh"]})]})]}),e.jsxs("div",{className:"grid gap-4 md:grid-cols-3",children:[e.jsxs(_,{className:"border-border/60 bg-card/60",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Employees With Completed Work"}),e.jsx(k,{children:u.length})]}),e.jsx(S,{children:e.jsx("p",{className:"text-sm text-muted-foreground",children:i})})]}),e.jsxs(_,{className:"border-border/60 bg-card/60",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Completed Work Items"}),e.jsx(k,{children:he.assignmentCount})]}),e.jsx(S,{children:e.jsx("p",{className:"text-sm text-muted-foreground",children:"Month-wise delivered work ready for invoice."})})]}),e.jsxs(_,{className:"border-border/60 bg-card/60",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Total Amount Tracked"}),e.jsx(k,{children:E(he.totalAmount)})]}),e.jsx(S,{children:e.jsxs("p",{className:"text-sm text-muted-foreground",children:[l.length," invoices already sent in this month."]})})]})]}),e.jsxs("div",{className:"grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]",children:[e.jsxs(_,{className:"border-border/60 bg-card/65",children:[e.jsxs(I,{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx(k,{className:"text-xl",children:"Employee Work List"}),e.jsx($,{children:"Choose an employee to build the invoice draft."})]}),e.jsxs("div",{className:"relative",children:[e.jsx(Oe,{className:"pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-muted-foreground"}),e.jsx(V,{value:A,onChange:t=>Ce(t.target.value),placeholder:"Search employee...",className:"pl-9"})]})]}),e.jsx(S,{className:"space-y-3",children:B?e.jsxs("div",{className:"flex items-center justify-center py-16 text-sm text-muted-foreground",children:[e.jsx(M,{className:"mr-2 h-4 w-4 animate-spin"}),"Loading invoice source..."]}):ue.length===0?e.jsxs("div",{className:"rounded-2xl border border-dashed border-border/60 px-4 py-10 text-center text-sm text-muted-foreground",children:["No completed employee work found for ",i,"."]}):ue.map(t=>{const n=P===t.employee_id,o=t.assignments.filter(c=>c.already_invoiced).length;return e.jsxs("button",{type:"button",onClick:()=>Ae(t),className:`w-full rounded-2xl border p-4 text-left transition-all ${n?"border-primary/45 bg-primary/10 shadow-[0_14px_30px_rgba(239,68,68,0.12)]":"border-border/60 bg-background/50 hover:border-primary/30 hover:bg-background"}`,children:[e.jsxs("div",{className:"flex items-start justify-between gap-3",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-base font-semibold text-foreground",children:t.employee_name}),e.jsx("p",{className:"text-sm text-muted-foreground",children:t.employee_email}),t.profession?e.jsx("p",{className:"mt-1 text-xs uppercase tracking-[0.16em] text-muted-foreground/80",children:t.profession}):null]}),n?e.jsx(Ue,{className:"h-5 w-5 text-primary"}):null]}),e.jsxs("div",{className:"mt-4 flex flex-wrap gap-2",children:[e.jsxs(w,{variant:"secondary",children:[t.assignment_count," works"]}),e.jsx(w,{variant:"outline",children:E(t.total_amount)}),o>0?e.jsxs(w,{className:"border-amber-500/30 bg-amber-500/15 text-amber-700",children:[o," already invoiced"]}):null]})]},t.employee_id)})})]}),e.jsxs(_,{className:"border-border/60 bg-card/70",children:[e.jsxs(I,{className:"flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between",children:[e.jsxs("div",{children:[e.jsx(k,{className:"text-xl",children:"Invoice Builder"}),e.jsx($,{children:a?`${a.employee_name} · ${i}`:"Select an employee from the left to start the invoice."})]}),e.jsxs("div",{className:"flex flex-wrap gap-2",children:[e.jsxs(N,{type:"button",variant:"outline",className:"gap-2",onClick:Te,disabled:!a,children:[e.jsx(se,{className:"h-4 w-4"}),"Download / Print"]}),e.jsxs(N,{type:"button",className:"gap-2",onClick:ze,disabled:!a||ae,children:[ae?e.jsx(M,{className:"h-4 w-4 animate-spin"}):e.jsx(He,{className:"h-4 w-4"}),"Send Invoice"]})]})]}),e.jsx(S,{className:"space-y-6",children:a?e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"rounded-2xl border border-border/60 bg-background/45 p-4",children:e.jsxs("div",{className:"flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-lg font-semibold text-foreground",children:a.employee_name}),e.jsx("p",{className:"text-sm text-muted-foreground",children:a.employee_email})]}),e.jsxs("div",{className:"flex flex-wrap gap-2",children:[e.jsxs(w,{variant:"secondary",children:[a.assignments.length," completed works"]}),e.jsx(w,{variant:"outline",children:E(a.total_amount)})]})]})}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-center justify-between gap-3",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-base font-semibold",children:"Completed Work Items"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Uncheck any work you do not want to include in this month's invoice."})]}),e.jsxs(w,{variant:"outline",children:[R.length," selected"]})]}),e.jsx("div",{className:"space-y-3",children:a.assignments.length===0?e.jsxs("div",{className:"rounded-2xl border border-dashed border-border/60 px-4 py-8 text-center text-sm text-muted-foreground",children:["No completed assignments found for this employee in ",i,"."]}):a.assignments.map(t=>e.jsxs("label",{className:`flex cursor-pointer gap-3 rounded-2xl border p-4 transition-colors ${R.includes(t.id)?"border-primary/35 bg-primary/5":"border-border/60 bg-background/35 hover:bg-background/60"}`,children:[e.jsx(qe,{checked:R.includes(t.id),onCheckedChange:n=>Ee(t.id,n===!0),className:"mt-1"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsxs("div",{className:"flex flex-col gap-2 lg:flex-row lg:items-start lg:justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-foreground",children:t.work_title}),e.jsxs("p",{className:"mt-1 text-xs uppercase tracking-[0.16em] text-muted-foreground/80",children:[t.order_code||"Custom order"," · Completed ",J(t.completed_at)]}),t.work_details?e.jsx("p",{className:"mt-2 text-sm text-muted-foreground",children:t.work_details}):null]}),e.jsxs("div",{className:"shrink-0 text-right",children:[e.jsx("p",{className:"text-sm font-semibold text-foreground",children:E(t.payment_amount)}),e.jsx(w,{className:t.payment_status==="paid"?"mt-2 border-emerald-500/30 bg-emerald-500/15 text-emerald-700":"mt-2 border-rose-500/30 bg-rose-500/15 text-rose-700",children:t.payment_status})]})]}),t.already_invoiced?e.jsx("div",{className:"mt-3 flex flex-wrap gap-2",children:t.existing_invoice_numbers.map(n=>e.jsxs(w,{className:"border-amber-500/30 bg-amber-500/15 text-amber-700",children:["Included in ",n]},n))}):null]})]},t.id))})]}),e.jsxs("div",{className:"space-y-3 rounded-2xl border border-border/60 bg-background/35 p-4",children:[e.jsxs("div",{className:"flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-base font-semibold",children:"Custom Items"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Add any extra billable item that is not part of the completed assignment list."})]}),e.jsxs(N,{type:"button",variant:"outline",className:"gap-2",onClick:()=>O(t=>[...t,st()]),children:[e.jsx(We,{className:"h-4 w-4"}),"Add Item"]})]}),K.length===0?e.jsx("div",{className:"rounded-2xl border border-dashed border-border/60 px-4 py-8 text-center text-sm text-muted-foreground",children:"No custom item added yet."}):e.jsx("div",{className:"space-y-3",children:K.map((t,n)=>e.jsxs("div",{className:"rounded-2xl border border-border/60 bg-background/70 p-4",children:[e.jsxs("div",{className:"mb-3 flex items-center justify-between gap-3",children:[e.jsxs("p",{className:"text-sm font-medium text-foreground",children:["Custom item ",n+1]}),e.jsx(N,{type:"button",size:"icon",variant:"ghost",className:"h-8 w-8 text-muted-foreground hover:text-destructive",onClick:()=>O(o=>o.filter(c=>c.id!==t.id)),children:e.jsx(Qe,{className:"h-4 w-4"})})]}),e.jsxs("div",{className:"grid gap-3 lg:grid-cols-[minmax(0,1fr)_180px]",children:[e.jsx(V,{value:t.title,onChange:o=>X(t.id,{title:o.target.value}),placeholder:"Extra work title"}),e.jsx(V,{type:"number",min:"0",step:"0.01",value:t.amount,onChange:o=>X(t.id,{amount:o.target.value}),placeholder:"Amount"})]}),e.jsx(we,{value:t.description,onChange:o=>X(t.id,{description:o.target.value}),placeholder:"Optional details",rows:3,className:"mt-3"})]},t.id))})]}),e.jsxs("div",{className:"space-y-2",children:[e.jsx("label",{htmlFor:"invoice-notes",className:"text-sm font-medium",children:"Notes"}),e.jsx(we,{id:"invoice-notes",rows:4,value:U,onChange:t=>oe(t.target.value),placeholder:"Optional message, payment note, or summary for this invoice..."})]}),e.jsx("div",{className:"rounded-2xl border border-primary/20 bg-primary/[0.06] p-5",children:e.jsxs("div",{className:"flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm font-medium uppercase tracking-[0.18em] text-muted-foreground",children:"Invoice Summary"}),e.jsxs("div",{className:"mt-2 flex flex-wrap gap-2",children:[e.jsxs(w,{variant:"secondary",children:[h.printableItems.length," items ready"]}),h.invalidCustomItems.length>0?e.jsxs(w,{className:"border-amber-500/30 bg-amber-500/15 text-amber-700",children:["Fix custom item ",h.invalidCustomItems.join(", ")]}):null]})]}),e.jsxs("div",{className:"text-left lg:text-right",children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:"Total"}),e.jsx("p",{className:"text-3xl font-bold tracking-tight text-foreground",children:E(h.totalAmount)})]})]})})]}):e.jsx("div",{className:"rounded-2xl border border-dashed border-border/60 px-6 py-16 text-center text-sm text-muted-foreground",children:"Pick an employee to see month-wise completed work and prepare the invoice."})})]})]}),e.jsxs(_,{className:"border-border/60 bg-card/70",children:[e.jsx(I,{className:"flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",children:e.jsxs("div",{children:[e.jsx(k,{className:"text-xl",children:"Sent Invoice History"}),e.jsxs($,{children:["Invoices already sent for ",i,"."]})]})}),e.jsx(S,{children:e.jsx("div",{className:"rounded-2xl border border-border/60 overflow-hidden",children:e.jsxs(ve,{children:[e.jsx(ye,{children:e.jsxs(L,{children:[e.jsx(C,{children:"Invoice"}),e.jsx(C,{children:"Employee"}),e.jsx(C,{children:"Items"}),e.jsx(C,{children:"Total"}),e.jsx(C,{children:"Sent"}),e.jsx(C,{className:"text-right",children:"Actions"})]})}),e.jsx(Ne,{children:B?e.jsx(L,{children:e.jsx(v,{colSpan:6,className:"py-10 text-center text-muted-foreground",children:"Loading invoices..."})}):l.length===0?e.jsx(L,{children:e.jsxs(v,{colSpan:6,className:"py-10 text-center text-muted-foreground",children:["No invoices have been sent for ",i," yet."]})}):l.map(t=>e.jsxs(L,{children:[e.jsx(v,{children:e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"font-medium",children:t.invoice_number}),e.jsx("p",{className:"text-xs text-muted-foreground",children:String(t.invoice_month).slice(0,7)})]})}),e.jsx(v,{children:e.jsxs("div",{className:"space-y-1",children:[e.jsx("p",{className:"font-medium",children:t.employee_name}),e.jsx("p",{className:"text-xs text-muted-foreground",children:t.employee_email})]})}),e.jsx(v,{children:e.jsxs("div",{className:"space-y-1",children:[e.jsxs("p",{className:"font-medium",children:[t.item_count," items"]}),e.jsxs("p",{className:"text-xs text-muted-foreground",children:[t.assignment_count," linked works"]})]})}),e.jsx(v,{className:"font-semibold",children:E(t.total_amount)}),e.jsx(v,{children:J(t.sent_at)}),e.jsx(v,{children:e.jsxs("div",{className:"flex justify-end gap-2",children:[e.jsx(N,{type:"button",size:"icon",variant:"outline",onClick:()=>Fe(t.id),children:e.jsx(Ve,{className:"h-4 w-4"})}),e.jsx(N,{type:"button",size:"icon",variant:"outline",onClick:()=>Pe(t.id),disabled:ce===t.id,children:ce===t.id?e.jsx(M,{className:"h-4 w-4 animate-spin"}):e.jsx(se,{className:"h-4 w-4"})}),e.jsx(N,{type:"button",size:"icon",variant:"outline",onClick:()=>be(t),disabled:xe===t.id,children:xe===t.id?e.jsx(M,{className:"h-4 w-4 animate-spin"}):e.jsx(je,{className:"h-4 w-4"})})]})})]},t.id))})]})})})]}),e.jsx(Je,{open:!!De,onOpenChange:t=>{t||(Q(null),le(null))},children:e.jsxs(Ye,{className:"max-h-[90vh] max-w-4xl overflow-y-auto",children:[e.jsxs(Ze,{children:[e.jsx(Ge,{children:(d==null?void 0:d.invoice.invoice_number)||"Invoice Details"}),e.jsx(Ke,{children:d?`${d.invoice.employee_name} · ${G(String(d.invoice.invoice_month).slice(0,7))}`:"Invoice details"})]}),$e?e.jsxs("div",{className:"flex items-center justify-center py-16 text-sm text-muted-foreground",children:[e.jsx(M,{className:"mr-2 h-4 w-4 animate-spin"}),"Loading invoice details..."]}):d?e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"grid gap-4 md:grid-cols-3",children:[e.jsxs(_,{className:"border-border/60 bg-background/40",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Employee"}),e.jsx(k,{className:"text-lg",children:d.invoice.employee_name})]}),e.jsx(S,{children:e.jsx("p",{className:"text-sm text-muted-foreground",children:d.invoice.employee_email})})]}),e.jsxs(_,{className:"border-border/60 bg-background/40",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Sent At"}),e.jsx(k,{className:"text-lg",children:J(d.invoice.sent_at)})]}),e.jsx(S,{children:e.jsxs("p",{className:"text-sm text-muted-foreground",children:["Last emailed ",J(d.invoice.emailed_at)]})})]}),e.jsxs(_,{className:"border-border/60 bg-background/40",children:[e.jsxs(I,{className:"pb-3",children:[e.jsx($,{children:"Total"}),e.jsx(k,{className:"text-lg",children:E(d.items.reduce((t,n)=>t+n.amount,0))})]}),e.jsx(S,{children:e.jsxs("p",{className:"text-sm text-muted-foreground",children:[d.items.length," line items"]})})]})]}),e.jsx("div",{className:"rounded-2xl border border-border/60 overflow-hidden",children:e.jsxs(ve,{children:[e.jsx(ye,{children:e.jsxs(L,{children:[e.jsx(C,{children:"Order"}),e.jsx(C,{children:"Title"}),e.jsx(C,{children:"Description"}),e.jsx(C,{className:"text-right",children:"Amount"})]})}),e.jsx(Ne,{children:d.items.map(t=>e.jsxs(L,{children:[e.jsx(v,{children:t.order_code||"Custom"}),e.jsx(v,{children:t.title}),e.jsx(v,{children:t.item_type==="custom"&&Se(t.description)||"-"}),e.jsx(v,{className:"text-right font-semibold",children:E(t.amount)})]},t.id))})]})}),d.invoice.notes?e.jsxs(_,{className:"border-border/60 bg-background/40",children:[e.jsx(I,{className:"pb-3",children:e.jsx(k,{className:"text-base",children:"Notes"})}),e.jsx(S,{children:e.jsx("p",{className:"whitespace-pre-wrap text-sm text-muted-foreground",children:d.invoice.notes})})]}):null,e.jsxs("div",{className:"flex flex-wrap justify-end gap-2",children:[e.jsxs(N,{type:"button",variant:"outline",className:"gap-2",onClick:()=>q(ke(d)),children:[e.jsx(se,{className:"h-4 w-4"}),"Download / Print"]}),e.jsxs(N,{type:"button",className:"gap-2",onClick:()=>be({...d.invoice,item_count:d.items.length,assignment_count:d.items.filter(t=>t.work_assignment_id).length}),children:[e.jsx(je,{className:"h-4 w-4"}),"Resend"]})]})]}):e.jsx("div",{className:"py-10 text-center text-sm text-muted-foreground",children:"Invoice details could not be loaded."})]})})]})};export{ft as default};

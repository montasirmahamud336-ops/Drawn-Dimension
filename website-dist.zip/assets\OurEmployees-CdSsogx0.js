import{j as e,bJ as t}from"./index-CvesnZYi.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

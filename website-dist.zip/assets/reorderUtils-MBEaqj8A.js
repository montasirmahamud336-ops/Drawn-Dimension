const f=(n,r,t)=>{if(r===t)return n;const e=n.findIndex(c=>c.id===r),d=n.findIndex(c=>c.id===t);if(e<0||d<0||e===d)return n;const o=[...n],[x]=o.splice(e,1);return o.splice(d,0,x),o};export{f as m};

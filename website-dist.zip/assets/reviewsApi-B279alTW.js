import{g as r}from"./index-DhY9vPz0.js";const s=()=>{const e="https://api.drawndimension.com";return e.trim().length>0?e.replace(/\/$/,""):r().replace(/\/$/,"")};export{s as g};

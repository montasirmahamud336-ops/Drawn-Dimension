import{r as i,j as e}from"./vendor-radix-Phst1WNl.js";import{g as ot,n as Y,q as x,B as p,T as at,o as it,p as lt}from"./index-DhY9vPz0.js";import{B as E}from"./badge-LshkldTG.js";import{C as dt}from"./checkbox-Dtuz7n0S.js";import{D as _e,a as Ae,b as Ie,c as $e,e as Te,d as ct}from"./dialog-DGCpsC72.js";import{I as $}from"./input-D3dfovrj.js";import{kQ as mt,b_ as xt,jt as ut,id as pt,o as ht,dV as gt,S as bt,l7 as ft,O as yt,jJ as De,d$ as J,kI as Nt,c4 as jt,ch as oe,jI as vt,kK as wt,kX as kt,kn as St,ki as Ct,kA as Ee}from"./vendor-icons-DC1--fo9.js";import"./vendor-query-BZDBF-Bn.js";import"./vendor-motion-D-Lmnm1a.js";const k=r=>r.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;"),ze=r=>`BDT ${new Intl.NumberFormat("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2}).format(r)}`,_t=r=>{const n=new Date(r);return Number.isNaN(n.getTime())?r:n.toLocaleDateString("en-BD",{year:"numeric",month:"long",day:"numeric"})},At=r=>{const n=(r==null?void 0:r.trim())||"";return!n||n.toLowerCase()==="no additional details"?null:n},It=r=>{var b;const n=r.items.map((m,N)=>{var L;const v=k(((L=m.orderCode)==null?void 0:L.trim())||"Custom"),X=k(m.title),S=k(ze(m.amount)),P=At(m.description),C=P?`<span>${k(P)}</span>`:"";return`
        <tr>
          <td>${N+1}</td>
          <td>${v}</td>
          <td>
            <strong>${X}</strong>
            ${C}
          </td>
          <td class="amount">${S}</td>
        </tr>
      `}).join("");return`
    <!doctype html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>${k(r.invoiceNumber)}</title>
        <style>
          :root {
            color-scheme: light;
            --ink: #0f172a;
            --muted: #64748b;
            --line: #dbe5f1;
            --soft: #f8fafc;
            --accent: #ef4444;
          }
          * { box-sizing: border-box; }
          body {
            margin: 0;
            font-family: "Segoe UI", Arial, sans-serif;
            color: var(--ink);
            background: #eef2f7;
          }
          .page {
            max-width: 920px;
            margin: 32px auto;
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: 22px;
            overflow: hidden;
            box-shadow: 0 18px 50px rgba(15, 23, 42, 0.08);
          }
          .toolbar {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: center;
            padding: 16px 24px;
            background: rgba(15, 23, 42, 0.95);
            color: #ffffff;
          }
          .toolbar button {
            border: 0;
            border-radius: 999px;
            padding: 10px 16px;
            background: #ffffff;
            color: var(--ink);
            font-weight: 600;
            cursor: pointer;
          }
          .hero {
            padding: 30px 32px 26px;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #ffffff;
          }
          .hero p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: rgba(255, 255, 255, 0.72);
          }
          .hero h1 {
            margin: 0;
            font-size: 32px;
            line-height: 1.1;
          }
          .content {
            padding: 28px 32px 32px;
          }
          .meta {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 24px;
          }
          .meta-card {
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: var(--soft);
          }
          .meta-card p {
            margin: 0 0 6px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .meta-card h2 {
            margin: 0;
            font-size: 18px;
          }
          .meta-card .sub {
            margin-top: 8px;
            font-size: 14px;
            color: #475569;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 16px;
          }
          th, td {
            padding: 14px 12px;
            text-align: left;
            border-bottom: 1px solid var(--line);
            vertical-align: top;
          }
          th {
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
            background: var(--soft);
          }
          td strong {
            display: block;
            margin-bottom: 6px;
            font-size: 14px;
          }
          td span {
            display: block;
            font-size: 13px;
            line-height: 1.55;
            color: #475569;
          }
          td.amount {
            text-align: right;
            font-weight: 700;
            white-space: nowrap;
          }
          .notes {
            margin-top: 18px;
            padding: 18px;
            border: 1px solid var(--line);
            border-radius: 16px;
            background: var(--soft);
          }
          .notes p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .notes div {
            font-size: 14px;
            line-height: 1.7;
            color: #334155;
            white-space: pre-wrap;
          }
          .total {
            margin-top: 20px;
            padding: 20px 24px;
            border-radius: 18px;
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.08), rgba(15, 23, 42, 0.05));
            border: 1px solid rgba(239, 68, 68, 0.2);
            text-align: right;
          }
          .total p {
            margin: 0 0 8px;
            font-size: 12px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--muted);
          }
          .total h3 {
            margin: 0;
            font-size: 30px;
          }
          @media (max-width: 720px) {
            .page { margin: 0; border-radius: 0; }
            .toolbar, .hero, .content { padding-left: 18px; padding-right: 18px; }
            .meta { grid-template-columns: 1fr; }
            th, td { padding-left: 10px; padding-right: 10px; }
          }
          @media print {
            body { background: #ffffff; }
            .page {
              margin: 0;
              max-width: none;
              border: 0;
              border-radius: 0;
              box-shadow: none;
            }
            .toolbar { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="page">
          <div class="toolbar">
            <div>Use your browser print dialog to save this invoice as PDF.</div>
            <button type="button" onclick="window.print()">Print / Save PDF</button>
          </div>

          <section class="hero">
            <p>Employee Invoice</p>
            <h1>${k(r.monthLabel)}</h1>
          </section>

          <section class="content">
            <div class="meta">
              <div class="meta-card">
                <p>Invoice To</p>
                <h2>${k(r.employeeName)}</h2>
                <div class="sub">${k(r.employeeEmail)}</div>
              </div>
              <div class="meta-card">
                <p>Invoice Info</p>
                <h2>${k(r.invoiceNumber)}</h2>
                <div class="sub">Sent: ${k(_t(r.sentAt))}</div>
              </div>
            </div>

            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Order</th>
                  <th>Work</th>
                  <th style="text-align:right;">Amount</th>
                </tr>
              </thead>
              <tbody>${n}</tbody>
            </table>

            ${(b=r.notes)!=null&&b.trim()?`
                  <div class="notes">
                    <p>Notes</p>
                    <div>${k(r.notes.trim())}</div>
                  </div>
                `:""}

            <div class="total">
              <p>Total</p>
              <h3>${k(ze(r.totalAmount))}</h3>
            </div>
          </section>
        </div>
        <script>
          window.addEventListener("load", function () {
            window.setTimeout(function () {
              try {
                window.print();
              } catch (error) {
                console.error(error);
              }
            }, 300);
          });
        <\/script>
      </body>
    </html>
  `},K=r=>{const n=window.open("","_blank","noopener,noreferrer,width=1100,height=900");if(!n)throw new Error("Popup blocked. Please allow popups to print or save the invoice.");n.document.open(),n.document.write(It(r)),n.document.close()},M=()=>{const r=new Date;return`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,"0")}`},Fe=(r,n)=>{const[b,m]=String(r||M()).split("-"),N=new Date(parseInt(b,10)||new Date().getFullYear(),(parseInt(m,10)||1)-1+n,1);return`${N.getFullYear()}-${String(N.getMonth()+1).padStart(2,"0")}`},Me=r=>{if(!r)return"EM";const n=String(r).trim().split(/\s+/).filter(Boolean);return n.length===0?"EM":n.length===1?(n[0].slice(0,2)||"EM").toUpperCase():((n[0][0]||"")+(n[1][0]||"")).toUpperCase()||"EM"},ae=r=>{if(r==null)return null;const n=Number(String(r).replace(/,/g,"").trim());return!Number.isFinite(n)||n<0?null:Number(n.toFixed(2))},y=r=>{const n=Number.isFinite(r)?r:0;return`BDT ${new Intl.NumberFormat("en-BD",{minimumFractionDigits:2,maximumFractionDigits:2}).format(n)}`},G=r=>{if(!r)return"-";const[n,b]=String(r).split("-").map(Number);if(!n||!b||Number.isNaN(n)||Number.isNaN(b))return String(r);try{return new Date(Date.UTC(n,b-1,1)).toLocaleDateString("en-BD",{year:"numeric",month:"long",timeZone:"UTC"})}catch{return String(r)}},Pe=r=>{if(!r)return"-";const n=new Date(r);return Number.isNaN(n.getTime())?"-":n.toLocaleDateString("en-BD",{day:"numeric",month:"short",year:"numeric"})},$t=r=>{const n=(r==null?void 0:r.trim())||"";return!n||n.toLowerCase()==="no additional details"?null:n},Q=async(r,n)=>{if((r.headers.get("content-type")||"").includes("application/json")){const N=await r.json().catch(()=>null);if(N!=null&&N.message){const v=String(N.message);return v.includes("completed_at")&&v.includes("does not exist")?"Invoice migration is missing. Please run database migrations first.":v.includes("employee_invoices")||v.includes("employee_invoice_line_items")?"Invoice tables are missing in the database. Please check PostgreSQL migrations.":v}}const m=await r.text().catch(()=>"");return m||n},Le=r=>({invoiceNumber:r.invoice.invoice_number,monthLabel:G(String(r.invoice.invoice_month||"").slice(0,7)),employeeName:r.invoice.employee_name,employeeEmail:r.invoice.employee_email,sentAt:r.invoice.sent_at,totalAmount:(r.items||[]).reduce((n,b)=>n+(Number(b.amount)||0),0),notes:r.invoice.notes??null,items:(r.items||[]).map(n=>({orderCode:n.order_code,title:n.title,description:n.item_type==="custom"?$t(n.description):null,amount:Number(n.amount)||0}))});function Ut(){var Ce;const r=ot(),[n,b]=i.useState("studio"),[m,N]=i.useState(M),[v,X]=i.useState(G(M())),[S,P]=i.useState([]),[C,L]=i.useState([]),[B,ie]=i.useState(!0),[Z,Be]=i.useState(""),[T,ee]=i.useState("all"),[_,le]=i.useState(""),[U,I]=i.useState([]),[w,R]=i.useState([]),[O,te]=i.useState(""),[Ue,V]=i.useState(!1),[de,ce]=i.useState(""),[me,xe]=i.useState(""),[ue,pe]=i.useState(""),[he,ge]=i.useState(!1),[H,Re]=i.useState(""),[Oe,se]=i.useState(null),[u,be]=i.useState(null),[Ve,fe]=i.useState(!1),[He,ye]=i.useState(null),[qe,Ne]=i.useState(null),z=i.useCallback(async(t,s=_,o=!1)=>{var h;const c=Y();if(!c){x.error("Session expired. Please login again.");return}ie(!0);try{const a=await fetch(`${r}/employee-invoices/source?month=${encodeURIComponent(t)}`,{headers:{Authorization:`Bearer ${c}`}});if(!a.ok)throw new Error(await Q(a,"Failed to load invoice data"));const d=await a.json(),j=Array.isArray(d==null?void 0:d.employees)?d.employees:[],g=Array.isArray(d==null?void 0:d.sent_invoices)?d.sent_invoices:[];P(j),L(g),X(String((d==null?void 0:d.month_label)||G(t)));const ne=j.some(D=>D.employee_id===s)?s:((h=j[0])==null?void 0:h.employee_id)??"";if(le(ne),!o||ne!==s){const D=j.find(W=>W.employee_id===ne)??null;if(D&&Array.isArray(D.assignments)){const W=D.assignments.filter(F=>!F.already_invoiced).map(F=>F.id);I(W.length>0?W:D.assignments.map(F=>F.id))}else I([]);R([]),te("")}}catch(a){console.error(a),x.error(a instanceof Error?a.message:"Failed to load invoice records")}finally{ie(!1)}},[r,_]);i.useEffect(()=>{z(m,_,!1)},[m,z,_]);const l=i.useMemo(()=>(S||[]).find(t=>t&&t.employee_id===_)??null,[S,_]),A=i.useMemo(()=>!l||!Array.isArray(l.assignments)?[]:l.assignments.filter(t=>t&&U.includes(t.id)),[l,U]),je=i.useMemo(()=>A.reduce((t,s)=>t+(Number(s.payment_amount)||0),0),[A]),q=i.useMemo(()=>(w||[]).reduce((t,s)=>t+(Number(s.amount)||0),0),[w]),re=je+q,ve=i.useMemo(()=>(S||[]).filter(t=>{if(!t)return!1;const s=String(t.employee_name||"").toLowerCase(),o=String(t.employee_email||"").toLowerCase(),c=String(t.profession||"").toLowerCase(),h=(Z||"").toLowerCase().trim();if(h&&!s.includes(h)&&!o.includes(h)&&!c.includes(h))return!1;const a=Array.isArray(t.assignments)?t.assignments:[],d=a.some(g=>g&&!g.already_invoiced),j=a.length>0&&a.every(g=>g&&g.already_invoiced);return T==="pending"?d:T==="invoiced"?j:!0}),[S,Z,T]),f=i.useMemo(()=>{let t=0,s=0,o=0,c=0;(S||[]).forEach(a=>{if(!a)return;t+=Number(a.assignment_count)||0,s+=Number(a.total_amount)||0,(Array.isArray(a.assignments)?a.assignments:[]).forEach(j=>{j&&!j.already_invoiced&&(o+=Number(j.payment_amount)||0,c+=1)})});const h=(C||[]).reduce((a,d)=>a+(Number(d.total_amount)||0),0);return{employeeCount:(S||[]).length,assignmentCount:t,grossAmount:s,unbilledAmount:o,unbilledTasks:c,sentCount:(C||[]).length,sentTotalAmount:h}},[S,C]),we=i.useMemo(()=>{if(!H.trim())return C||[];const t=H.toLowerCase().trim();return(C||[]).filter(s=>{if(!s)return!1;const o=String(s.invoice_number||"").toLowerCase(),c=String(s.employee_name||"").toLowerCase(),h=String(s.employee_email||"").toLowerCase();return o.includes(t)||c.includes(t)||h.includes(t)})},[C,H]),We=t=>{if(!t)return;le(t.employee_id);const s=Array.isArray(t.assignments)?t.assignments:[],o=s.filter(c=>c&&!c.already_invoiced).map(c=>c.id);I(o.length>0?o:s.map(c=>c.id)),R([]),te("")},Ye=(t,s)=>{I(o=>s?[...o,t]:o.filter(c=>c!==t))},Je=()=>{if(!l||!Array.isArray(l.assignments))return;const t=l.assignments.filter(s=>s&&!s.already_invoiced).map(s=>s.id);I(t)},Ke=()=>{!l||!Array.isArray(l.assignments)||I(l.assignments.map(t=>t.id))},Qe=()=>{I([])},Ge=()=>{const t=de.trim(),s=Number(ue);if(!t){x.error("Please enter an item title");return}if(!Number.isFinite(s)||s<=0){x.error("Please enter a valid amount greater than 0");return}const o={id:`custom-${Date.now()}`,title:t,description:me.trim(),amount:s};R(c=>[...c,o]),ce(""),xe(""),pe(""),V(!1),x.success("Custom item added")},Xe=t=>{R(s=>s.filter(o=>o.id!==t))},Ze=()=>{if(!l)return null;const t=[];return A.forEach(s=>{t.push({orderCode:s.order_code,title:s.work_title,description:s.work_details,amount:Number(s.payment_amount)||0})}),w.forEach(s=>{t.push({orderCode:"Custom",title:s.title,description:s.description||null,amount:Number(s.amount)||0})}),{invoiceNumber:`DRAFT-${String(m).replace("-","")}-${String(l.employee_name||"STAFF").replace(/\s+/g,"-").toUpperCase()}`,monthLabel:v,employeeName:l.employee_name||"Staff",employeeEmail:l.employee_email||"",sentAt:new Date().toISOString(),totalAmount:re,notes:O.trim()||null,items:t}},et=()=>{if(!l){x.error("Select an employee first");return}if(A.length===0&&w.length===0){x.error("Select at least one task or add a custom item");return}const t=Ze();if(t)try{K(t)}catch(s){x.error(s instanceof Error?s.message:"Could not open print window")}},tt=async()=>{var o,c,h;const t=Y();if(!t){x.error("Session expired. Please login again.");return}if(!l){x.error("Select an employee first");return}if(A.length===0&&w.length===0){x.error("Select at least one task or add a custom item");return}const s=[...A.map(a=>({work_assignment_id:a.id})),...w.map(a=>({title:a.title,description:a.description||null,amount:a.amount}))];ge(!0);try{const a=await fetch(`${r}/employee-invoices/send`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({employee_id:l.employee_id,invoice_month:m,notes:O.trim()||null,items:s})});if(!a.ok)throw new Error(await Q(a,"Failed to send invoice"));const d=await a.json(),j={invoiceNumber:String(((o=d==null?void 0:d.invoice)==null?void 0:o.invoice_number)||""),monthLabel:String((d==null?void 0:d.month_label)||v),employeeName:l.employee_name||"Staff",employeeEmail:l.employee_email||"",sentAt:String(((c=d==null?void 0:d.invoice)==null?void 0:c.sent_at)||new Date().toISOString()),totalAmount:ae((h=d==null?void 0:d.invoice)==null?void 0:h.total_amount)??re,notes:O.trim()||null,items:[...A.map(g=>({orderCode:g.order_code,title:g.work_title,description:g.work_details,amount:Number(g.payment_amount)||0})),...w.map(g=>({orderCode:"Custom",title:g.title,description:g.description||null,amount:Number(g.amount)||0}))]};x.success(`Invoice ${j.invoiceNumber} emailed to ${l.employee_email}!`);try{K(j)}catch{}z(m,l.employee_id,!1)}catch(a){console.error(a),x.error(a instanceof Error?a.message:"Failed to dispatch invoice")}finally{ge(!1)}},ke=async t=>{const s=Y();if(!s)return x.error("Session expired. Please login again."),null;const o=await fetch(`${r}/employee-invoices/${encodeURIComponent(t)}`,{headers:{Authorization:`Bearer ${s}`}});if(!o.ok)throw new Error(await Q(o,"Failed to load invoice details"));const c=await o.json();return{invoice:{...c.invoice,total_amount:ae(c.invoice.total_amount)??0},items:Array.isArray(c.items)?c.items.map(h=>({...h,amount:ae(h.amount)??0})):[]}},st=async t=>{se(t),fe(!0);try{const s=await ke(t);if(!s)return;be(s)}catch(s){console.error(s),x.error(s instanceof Error?s.message:"Failed to load invoice"),se(null)}finally{fe(!1)}},rt=async t=>{ye(t);try{const s=await ke(t);if(!s)return;K(Le(s))}catch(s){console.error(s),x.error(s instanceof Error?s.message:"Could not open print window")}finally{ye(null)}},Se=async t=>{const s=Y();if(!s){x.error("Session expired. Please login again.");return}if(confirm(`Resend invoice ${t.invoice_number} to ${t.employee_email}?`)){Ne(t.id);try{const o=await fetch(`${r}/employee-invoices/${encodeURIComponent(t.id)}/resend`,{method:"POST",headers:{Authorization:`Bearer ${s}`}});if(!o.ok)throw new Error(await Q(o,"Failed to resend invoice"));x.success(`Invoice successfully resent to ${t.employee_email}`),z(m,_,!0)}catch(o){console.error(o),x.error(o instanceof Error?o.message:"Failed to resend invoice")}finally{Ne(null)}}},nt=(t,s="Invoice number")=>{navigator.clipboard.writeText(t),x.success(`${s} copied`)};return e.jsxs("div",{className:"space-y-3.5 pb-8",children:[e.jsxs("div",{className:"flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between border-b border-border/50 pb-3",children:[e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{className:"flex h-8 w-8 items-center justify-center rounded-xl bg-primary/10 text-primary",children:e.jsx(mt,{className:"h-4 w-4"})}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("h1",{className:"text-lg font-bold tracking-tight text-foreground",children:"Sent Invoices"}),e.jsx(E,{variant:"outline",className:"h-5 rounded-md border-primary/30 bg-primary/5 px-2 text-[10px] font-bold text-primary",children:v})]}),e.jsx("p",{className:"text-[11px] text-muted-foreground",children:"Monthly milestones & invoice dispatch studio"})]})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[e.jsxs("div",{className:"flex items-center rounded-xl border border-border/70 bg-background/80 p-0.5 shadow-sm",children:[e.jsx(p,{variant:"ghost",size:"sm",onClick:()=>N(Fe(m,-1)),className:"h-7 px-2 text-xs font-semibold hover:bg-primary/10",children:"Prev"}),e.jsx(p,{variant:m===M()?"secondary":"ghost",size:"sm",onClick:()=>N(M()),className:"h-7 px-2.5 text-xs font-bold",children:"This Month"}),e.jsx(p,{variant:"ghost",size:"sm",onClick:()=>N(Fe(m,1)),className:"h-7 px-2 text-xs font-semibold hover:bg-primary/10",children:"Next"})]}),e.jsx($,{type:"month",value:m,onChange:t=>N(t.target.value),className:"h-8 w-[145px] rounded-xl border-border/80 bg-background font-medium text-xs shadow-sm"}),e.jsx(p,{variant:"outline",size:"sm",onClick:()=>void z(m,_,!0),disabled:B,className:"h-8 w-8 rounded-xl p-0 shadow-sm hover:border-primary/40",title:"Refresh source data",children:e.jsx(xt,{className:`h-3.5 w-3.5 ${B?"animate-spin text-primary":"text-muted-foreground"}`})})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-2.5 sm:grid-cols-4",children:[e.jsxs("div",{className:"flex items-center gap-3 rounded-2xl border border-border/60 bg-card/60 px-3.5 py-2.5 shadow-sm backdrop-blur-md",children:[e.jsx("div",{className:"flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary",children:e.jsx(ut,{className:"h-4 w-4"})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-muted-foreground",children:"Billable Staff"}),e.jsxs("p",{className:"text-base font-black tracking-tight text-foreground",children:[f.employeeCount," ",e.jsx("span",{className:"text-[11px] font-normal text-muted-foreground",children:"members"})]})]})]}),e.jsxs("div",{className:"flex items-center gap-3 rounded-2xl border border-border/60 bg-card/60 px-3.5 py-2.5 shadow-sm backdrop-blur-md",children:[e.jsx("div",{className:"flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-blue-500/10 text-blue-500",children:e.jsx(pt,{className:"h-4 w-4"})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-muted-foreground",children:"Completed Tasks"}),f.unbilledTasks>0&&e.jsxs("span",{className:"rounded bg-amber-500/15 px-1 py-0.2 text-[9px] font-bold text-amber-600",children:[f.unbilledTasks," pending"]})]}),e.jsxs("p",{className:"text-base font-black tracking-tight text-foreground",children:[f.assignmentCount," ",e.jsx("span",{className:"text-[11px] font-normal text-muted-foreground",children:"tasks"})]})]})]}),e.jsxs("div",{className:"flex items-center gap-3 rounded-2xl border border-border/60 bg-card/60 px-3.5 py-2.5 shadow-sm backdrop-blur-md",children:[e.jsx("div",{className:"flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-500",children:e.jsx(ht,{className:"h-4 w-4"})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-muted-foreground",children:"Total Month Volume"}),e.jsx("p",{className:"text-base font-black tracking-tight text-emerald-600 dark:text-emerald-400 truncate",children:y(f.grossAmount)})]})]}),e.jsxs("div",{className:"flex items-center gap-3 rounded-2xl border border-border/60 bg-card/60 px-3.5 py-2.5 shadow-sm backdrop-blur-md",children:[e.jsx("div",{className:"flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500",children:e.jsx(gt,{className:"h-4 w-4"})}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-[10px] font-bold uppercase tracking-wider text-muted-foreground",children:"Invoices Sent"}),e.jsxs("p",{className:"text-base font-black tracking-tight text-foreground",children:[f.sentCount," ",e.jsx("span",{className:"text-[11px] font-normal text-muted-foreground",children:"statements"})]})]})]})]}),e.jsx("div",{className:"flex items-center justify-between border-b border-border/50 pb-2",children:e.jsxs("div",{className:"flex items-center gap-1 rounded-xl bg-muted/60 p-1",children:[e.jsxs("button",{onClick:()=>b("studio"),className:`flex items-center gap-1.5 rounded-lg px-3 py-1 text-xs font-bold transition-all ${n==="studio"?"bg-background text-primary shadow-sm":"text-muted-foreground hover:text-foreground"}`,children:[e.jsx(bt,{className:"h-3.5 w-3.5"}),"Invoice Studio"]}),e.jsxs("button",{onClick:()=>b("history"),className:`flex items-center gap-1.5 rounded-lg px-3 py-1 text-xs font-bold transition-all ${n==="history"?"bg-background text-primary shadow-sm":"text-muted-foreground hover:text-foreground"}`,children:[e.jsx(ft,{className:"h-3.5 w-3.5"}),"Sent Archive",C.length>0&&e.jsx("span",{className:"rounded-full bg-primary/10 px-1.5 py-0.2 text-[10px] font-bold text-primary",children:C.length})]}),e.jsxs("button",{onClick:()=>b("insights"),className:`flex items-center gap-1.5 rounded-lg px-3 py-1 text-xs font-bold transition-all ${n==="insights"?"bg-background text-primary shadow-sm":"text-muted-foreground hover:text-foreground"}`,children:[e.jsx(yt,{className:"h-3.5 w-3.5"}),"Payroll Insights"]})]})}),n==="studio"&&e.jsxs("div",{className:"grid grid-cols-1 gap-4 xl:grid-cols-[330px_minmax(0,1fr)]",children:[e.jsxs("div",{className:"rounded-2xl border border-border/60 bg-card/60 p-3 shadow-sm backdrop-blur-xl space-y-2.5",children:[e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"relative",children:[e.jsx(De,{className:"pointer-events-none absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground"}),e.jsx($,{placeholder:"Filter staff by name...",value:Z,onChange:t=>Be(t.target.value),className:"h-7.5 rounded-xl border-border/70 bg-background/80 pl-8 text-xs focus:border-primary"})]}),e.jsxs("div",{className:"flex gap-1",children:[e.jsxs("button",{onClick:()=>ee("all"),className:`flex-1 rounded-lg py-0.5 text-center text-[10px] font-bold transition-all ${T==="all"?"bg-primary text-primary-foreground shadow-xs":"bg-muted/60 text-muted-foreground hover:bg-muted"}`,children:["All (",S.length,")"]}),e.jsx("button",{onClick:()=>ee("pending"),className:`flex-1 rounded-lg py-0.5 text-center text-[10px] font-bold transition-all ${T==="pending"?"bg-amber-500 text-white shadow-xs":"bg-muted/60 text-muted-foreground hover:bg-muted"}`,children:"Pending Unbilled"}),e.jsx("button",{onClick:()=>ee("invoiced"),className:`flex-1 rounded-lg py-0.5 text-center text-[10px] font-bold transition-all ${T==="invoiced"?"bg-emerald-600 text-white shadow-xs":"bg-muted/60 text-muted-foreground hover:bg-muted"}`,children:"Invoiced"})]})]}),e.jsx("div",{className:"max-h-[520px] space-y-1.5 overflow-y-auto pr-0.5",children:B?e.jsxs("div",{className:"flex items-center justify-center py-10 text-xs text-muted-foreground",children:[e.jsx(J,{className:"mr-2 h-4 w-4 animate-spin text-primary"}),"Loading staff..."]}):ve.length===0?e.jsx("div",{className:"rounded-xl border border-dashed border-border/80 p-5 text-center text-xs text-muted-foreground",children:"No matching employees found."}):ve.map(t=>{const s=_===t.employee_id,o=Me(t.employee_name);return e.jsx("button",{onClick:()=>We(t),className:`group w-full rounded-xl border p-2 text-left transition-all duration-150 ${s?"border-primary/80 bg-primary/10 shadow-xs ring-1 ring-primary/30":"border-border/60 bg-background/50 hover:border-primary/40 hover:bg-accent/40"}`,children:e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{className:`flex h-7.5 w-7.5 shrink-0 items-center justify-center rounded-lg text-[11px] font-bold shadow-xs ${s?"bg-primary text-primary-foreground":"bg-primary/10 text-primary"}`,children:o}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsxs("div",{className:"flex items-center justify-between gap-1",children:[e.jsx("p",{className:"truncate text-xs font-bold text-foreground",children:t.employee_name}),s&&e.jsx(Nt,{className:"h-3.5 w-3.5 shrink-0 text-primary stroke-[3]"})]}),e.jsxs("div",{className:"flex items-center justify-between gap-1 mt-0.5",children:[e.jsxs("span",{className:"text-[10px] text-muted-foreground truncate",children:[t.assignment_count," works"]}),e.jsx("span",{className:"text-[11px] font-black text-emerald-600 dark:text-emerald-400",children:y(t.total_amount)})]})]})]})},t.employee_id)})})]}),e.jsx("div",{className:"space-y-2.5",children:l?e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("div",{className:"flex flex-col gap-2 rounded-2xl border border-border/60 bg-gradient-to-r from-card/90 via-card/70 to-primary/5 p-3 shadow-xs sm:flex-row sm:items-center sm:justify-between",children:[e.jsxs("div",{className:"flex items-center gap-2.5",children:[e.jsx("div",{className:"flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary text-xs font-black text-primary-foreground shadow-xs",children:Me(l.employee_name)}),e.jsxs("div",{children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("h3",{className:"text-sm font-bold text-foreground",children:l.employee_name}),e.jsx("span",{className:"rounded bg-muted px-1.5 py-0.2 text-[10px] font-semibold text-muted-foreground",children:l.profession||l.employee_email})]}),e.jsx("p",{className:"text-[11px] text-muted-foreground",children:l.employee_email})]})]}),e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsxs(p,{variant:"outline",size:"sm",onClick:et,disabled:A.length===0&&w.length===0,className:"h-8 rounded-xl px-3 text-xs font-bold shadow-xs hover:border-primary/40",children:[e.jsx(oe,{className:"mr-1.5 h-3.5 w-3.5"}),"Print Draft"]}),e.jsx(p,{size:"sm",onClick:tt,disabled:he||A.length===0&&w.length===0,className:"h-8 rounded-xl bg-primary px-3.5 text-xs font-bold text-primary-foreground shadow-xs hover:opacity-95",children:he?e.jsxs(e.Fragment,{children:[e.jsx(J,{className:"mr-1.5 h-3.5 w-3.5 animate-spin"}),"Sending..."]}):e.jsxs(e.Fragment,{children:[e.jsx(vt,{className:"mr-1.5 h-3.5 w-3.5"}),"Send Invoice"]})})]})]}),e.jsxs("div",{className:"flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border/50 bg-muted/40 px-3 py-1.5",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs("span",{className:"text-xs font-bold text-foreground",children:["Completed Tasks (",((Ce=l.assignments)==null?void 0:Ce.length)||0,")"]}),e.jsxs(E,{variant:"secondary",className:"h-5 text-[10px] font-bold",children:[U.length," Selected"]})]}),e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsx(p,{variant:"ghost",size:"sm",onClick:Je,className:"h-6 rounded-md px-2 text-[11px] font-semibold hover:bg-background",children:"Uninvoiced"}),e.jsx(p,{variant:"ghost",size:"sm",onClick:Ke,className:"h-6 rounded-md px-2 text-[11px] font-semibold hover:bg-background",children:"All"}),e.jsx(p,{variant:"ghost",size:"sm",onClick:Qe,className:"h-6 rounded-md px-2 text-[11px] font-semibold text-muted-foreground hover:bg-background",children:"Clear"}),e.jsxs(p,{variant:"outline",size:"sm",onClick:()=>V(!0),className:"h-6 rounded-md border-primary/30 bg-primary/5 px-2 text-[11px] font-bold text-primary hover:bg-primary/10",children:[e.jsx(wt,{className:"mr-1 h-3 w-3"}),"Custom Item"]})]})]}),e.jsx("div",{className:"max-h-[280px] space-y-1.5 overflow-y-auto pr-0.5",children:(l.assignments||[]).length===0?e.jsx("div",{className:"rounded-xl border border-dashed p-5 text-center text-xs text-muted-foreground",children:"No completed tasks for this employee."}):l.assignments.map(t=>{const s=U.includes(t.id);return e.jsxs("label",{className:`flex cursor-pointer items-center justify-between gap-3 rounded-xl border p-2 transition-all duration-100 ${s?"border-primary/50 bg-primary/[0.04] shadow-xs":"border-border/60 bg-background/50 opacity-70 hover:opacity-100"}`,children:[e.jsxs("div",{className:"flex items-center gap-2.5 min-w-0 flex-1",children:[e.jsx(dt,{checked:s,onCheckedChange:o=>Ye(t.id,o===!0),className:"h-4 w-4 rounded"}),e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"rounded bg-muted px-1.5 py-0.2 font-mono text-[10px] font-bold text-foreground",children:t.order_code||"TASK"}),e.jsx("span",{className:"truncate text-xs font-bold text-foreground",children:t.work_title}),t.already_invoiced&&e.jsx("span",{className:"rounded bg-amber-500/15 px-1.5 py-0.2 text-[9px] font-bold text-amber-700 dark:text-amber-400",children:"Invoiced"})]}),t.work_details&&e.jsx("p",{className:"mt-0.5 truncate text-[10px] text-muted-foreground",children:t.work_details})]})]}),e.jsx("span",{className:"text-xs font-bold text-emerald-600 dark:text-emerald-400 whitespace-nowrap",children:y(Number(t.payment_amount)||0)})]},t.id)})}),w.length>0&&e.jsxs("div",{className:"rounded-xl border border-border/60 bg-muted/20 p-2.5 space-y-1.5",children:[e.jsxs("div",{className:"flex items-center justify-between text-[11px] font-bold",children:[e.jsxs("span",{className:"text-primary uppercase",children:["Custom Line Items (",w.length,")"]}),e.jsxs("span",{className:"text-emerald-600 dark:text-emerald-400",children:["+",y(q)]})]}),e.jsx("div",{className:"space-y-1",children:w.map(t=>e.jsxs("div",{className:"flex items-center justify-between rounded-lg border border-border/50 bg-background/80 px-2.5 py-1 text-xs",children:[e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("span",{className:"font-bold text-foreground",children:t.title}),t.description&&e.jsx("span",{className:"text-[10px] text-muted-foreground ml-2",children:t.description})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"font-bold text-emerald-600 dark:text-emerald-400",children:y(t.amount)}),e.jsx(p,{variant:"ghost",size:"icon",onClick:()=>Xe(t.id),className:"h-5 w-5 text-rose-500 hover:bg-rose-500/10",children:e.jsx(kt,{className:"h-3 w-3"})})]})]},t.id))})]}),e.jsxs("div",{className:"flex flex-col gap-2 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-background p-3 sm:flex-row sm:items-center sm:justify-between shadow-sm",children:[e.jsx("div",{className:"flex-1 max-w-sm",children:e.jsx($,{placeholder:"Invoice notes / bank reference (optional)...",value:O,onChange:t=>te(t.target.value),className:"h-8 rounded-xl border-border/70 bg-background/90 text-xs"})}),e.jsxs("div",{className:"flex items-baseline justify-between sm:justify-end gap-3 text-right",children:[e.jsxs("div",{className:"text-xs text-muted-foreground",children:[e.jsxs("span",{children:["Tasks: ",y(je)]}),q>0&&e.jsxs("span",{className:"ml-2 text-emerald-600",children:["+",y(q)]})]}),e.jsxs("div",{className:"flex items-baseline gap-1.5",children:[e.jsx("span",{className:"text-xs font-bold text-primary",children:"Total:"}),e.jsx("span",{className:"text-xl font-black text-foreground",children:y(re)})]})]})]})]}):e.jsxs("div",{className:"flex h-[400px] flex-col items-center justify-center rounded-2xl border border-dashed border-border/80 bg-card/30 p-6 text-center",children:[e.jsx(jt,{className:"h-8 w-8 text-muted-foreground/40"}),e.jsx("h3",{className:"mt-2 text-sm font-bold text-foreground",children:"Select an employee"}),e.jsx("p",{className:"mt-0.5 text-xs text-muted-foreground",children:"Pick a team member from the directory to review tasks and send an invoice."})]})})]}),n==="history"&&e.jsxs("div",{className:"space-y-2.5",children:[e.jsxs("div",{className:"flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-border/60 bg-card/60 p-2.5 shadow-sm",children:[e.jsxs("div",{className:"relative flex-1 max-w-sm",children:[e.jsx(De,{className:"pointer-events-none absolute left-2.5 top-2 h-3.5 w-3.5 text-muted-foreground"}),e.jsx($,{placeholder:"Search invoice number, employee...",value:H,onChange:t=>Re(t.target.value),className:"h-7.5 rounded-xl border-border/70 bg-background/80 pl-8 text-xs focus:border-primary"})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsxs(E,{variant:"outline",className:"rounded-lg text-[10px] font-bold border-primary/30 bg-primary/5 text-primary",children:[C.length," Sent"]}),e.jsxs(E,{variant:"outline",className:"rounded-lg text-[10px] font-bold border-emerald-500/30 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400",children:["Total ",y(f.sentTotalAmount)]})]})]}),B?e.jsxs("div",{className:"flex items-center justify-center py-12 text-xs text-muted-foreground",children:[e.jsx(J,{className:"mr-2 h-4 w-4 animate-spin text-primary"}),"Loading sent invoices..."]}):we.length===0?e.jsxs("div",{className:"rounded-2xl border border-dashed border-border/80 p-8 text-center text-xs text-muted-foreground",children:["No sent invoices for ",v,"."]}):e.jsx("div",{className:"grid grid-cols-1 gap-2.5 md:grid-cols-2 xl:grid-cols-3",children:we.map(t=>e.jsxs("div",{className:"rounded-2xl border border-border/60 bg-card/60 p-3.5 shadow-sm backdrop-blur-md space-y-2.5",children:[e.jsxs("div",{className:"flex items-center justify-between gap-1",children:[e.jsxs("div",{className:"flex items-center gap-1.5",children:[e.jsx("span",{className:"font-mono text-xs font-bold text-foreground",children:t.invoice_number}),e.jsxs(at,{children:[e.jsx(it,{asChild:!0,children:e.jsx(p,{variant:"ghost",size:"icon",onClick:()=>nt(t.invoice_number),className:"h-5 w-5 text-muted-foreground hover:text-foreground",children:e.jsx(St,{className:"h-3 w-3"})})}),e.jsx(lt,{children:"Copy invoice number"})]})]}),e.jsx(E,{className:"h-5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 text-[9px] font-bold",children:"Sent"})]}),e.jsxs("div",{className:"flex items-center justify-between text-xs border-y border-border/40 py-1.5",children:[e.jsxs("div",{children:[e.jsx("p",{className:"font-bold text-foreground",children:t.employee_name}),e.jsx("p",{className:"text-[10px] text-muted-foreground",children:t.employee_email})]}),e.jsxs("div",{className:"text-right",children:[e.jsx("p",{className:"font-black text-emerald-600 dark:text-emerald-400",children:y(t.total_amount)}),e.jsxs("p",{className:"text-[10px] text-muted-foreground",children:[t.item_count," items"]})]})]}),e.jsxs("div",{className:"flex items-center justify-between gap-2 pt-0.5",children:[e.jsx("span",{className:"text-[10px] text-muted-foreground",children:Pe(t.sent_at)}),e.jsxs("div",{className:"flex items-center gap-1",children:[e.jsxs(p,{variant:"outline",size:"sm",onClick:()=>st(t.id),className:"h-6.5 rounded-lg px-2 text-[10px] font-bold",children:[e.jsx(Ct,{className:"mr-1 h-3 w-3"}),"View"]}),e.jsx(p,{variant:"outline",size:"sm",onClick:()=>rt(t.id),disabled:He===t.id,className:"h-6.5 rounded-lg px-2 text-[10px] font-bold",children:e.jsx(oe,{className:"h-3 w-3"})}),e.jsx(p,{variant:"outline",size:"sm",onClick:()=>Se(t),disabled:qe===t.id,className:"h-6.5 rounded-lg px-2 text-[10px] font-bold",children:e.jsx(Ee,{className:"h-3 w-3"})})]})]})]},t.id))})]}),n==="insights"&&e.jsxs("div",{className:"grid grid-cols-1 gap-4 lg:grid-cols-2",children:[e.jsxs("div",{className:"rounded-2xl border border-border/60 bg-card/60 p-4 shadow-sm space-y-3",children:[e.jsx("h3",{className:"text-sm font-bold text-foreground",children:"Completion Progress"}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"flex justify-between text-xs font-bold",children:[e.jsx("span",{children:"Billed Ratio"}),e.jsxs("span",{className:"text-primary",children:[f.grossAmount>0?Math.round(f.sentTotalAmount/f.grossAmount*100):0,"%"]})]}),e.jsx("div",{className:"h-2.5 w-full overflow-hidden rounded-full bg-muted",children:e.jsx("div",{className:"h-full rounded-full bg-primary transition-all duration-300",style:{width:`${f.grossAmount>0?Math.min(100,Math.round(f.sentTotalAmount/f.grossAmount*100)):0}%`}})}),e.jsxs("div",{className:"grid grid-cols-2 gap-2 pt-2 text-xs",children:[e.jsxs("div",{className:"rounded-xl border border-border/50 p-2",children:[e.jsx("p",{className:"text-[10px] text-muted-foreground",children:"Invoiced"}),e.jsx("p",{className:"font-bold",children:y(f.sentTotalAmount)})]}),e.jsxs("div",{className:"rounded-xl border border-border/50 p-2",children:[e.jsx("p",{className:"text-[10px] text-muted-foreground",children:"Unbilled"}),e.jsx("p",{className:"font-bold text-amber-600",children:y(f.unbilledAmount)})]})]})]})]}),e.jsxs("div",{className:"rounded-2xl border border-border/60 bg-card/60 p-4 shadow-sm space-y-3",children:[e.jsx("h3",{className:"text-sm font-bold text-foreground",children:"Staff Earnings"}),e.jsx("div",{className:"max-h-[160px] space-y-1.5 overflow-y-auto pr-0.5",children:S.slice().sort((t,s)=>(Number(s.total_amount)||0)-(Number(t.total_amount)||0)).map((t,s)=>e.jsxs("div",{className:"flex items-center justify-between rounded-xl border border-border/40 p-2 text-xs",children:[e.jsxs("span",{className:"font-bold text-foreground",children:["#",s+1," ",t.employee_name]}),e.jsx("span",{className:"font-bold text-emerald-600",children:y(Number(t.total_amount)||0)})]},t.employee_id))})]})]}),e.jsx(_e,{open:Ue,onOpenChange:V,children:e.jsxs(Ae,{className:"rounded-2xl border border-border/80 bg-card/95 p-5 sm:max-w-sm",children:[e.jsxs(Ie,{children:[e.jsx($e,{className:"text-base font-bold",children:"Add Custom Line Item"}),e.jsx(Te,{className:"text-xs",children:"Add a bonus, stipend, or manual adjustment to this invoice."})]}),e.jsxs("div",{className:"space-y-3 py-1",children:[e.jsxs("div",{className:"space-y-1",children:[e.jsx("label",{className:"text-[11px] font-bold",children:"Item Title *"}),e.jsx($,{placeholder:"e.g. Performance Bonus",value:de,onChange:t=>ce(t.target.value),className:"h-8 rounded-xl text-xs"})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("label",{className:"text-[11px] font-bold",children:"Description (Optional)"}),e.jsx($,{placeholder:"e.g. Approved project stipend",value:me,onChange:t=>xe(t.target.value),className:"h-8 rounded-xl text-xs"})]}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("label",{className:"text-[11px] font-bold",children:"Amount (BDT) *"}),e.jsx($,{type:"number",min:"0",placeholder:"e.g. 2000",value:ue,onChange:t=>pe(t.target.value),className:"h-8 rounded-xl text-xs font-mono font-bold"})]})]}),e.jsxs(ct,{className:"gap-1.5 sm:gap-0",children:[e.jsx(p,{variant:"outline",size:"sm",onClick:()=>V(!1),className:"h-7.5 rounded-xl text-xs",children:"Cancel"}),e.jsx(p,{size:"sm",onClick:Ge,className:"h-7.5 rounded-xl bg-primary text-xs font-bold text-primary-foreground",children:"Add Item"})]})]})}),e.jsx(_e,{open:!!Oe,onOpenChange:t=>{t||(se(null),be(null))},children:e.jsxs(Ae,{className:"max-h-[85vh] max-w-2xl overflow-y-auto rounded-2xl border border-border/80 bg-card/95 p-5",children:[e.jsx(Ie,{className:"border-b border-border/50 pb-3",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx($e,{className:"text-base font-bold text-foreground",children:(u==null?void 0:u.invoice.invoice_number)||"Invoice Statement"}),e.jsx(Te,{className:"text-xs text-muted-foreground",children:u?`${u.invoice.employee_name} · ${G(String(u.invoice.invoice_month||"").slice(0,7))}`:"Loading..."})]}),e.jsx(E,{className:"h-5 rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 text-[10px] font-bold",children:"Sent"})]})}),Ve?e.jsxs("div",{className:"flex items-center justify-center py-12 text-xs text-muted-foreground",children:[e.jsx(J,{className:"mr-2 h-4 w-4 animate-spin text-primary"}),"Loading statement..."]}):u?e.jsxs("div",{className:"space-y-4 pt-1",children:[e.jsxs("div",{className:"grid grid-cols-3 gap-2 text-xs",children:[e.jsxs("div",{className:"rounded-xl border border-border/60 p-2.5",children:[e.jsx("p",{className:"text-[10px] uppercase text-muted-foreground font-bold",children:"Recipient"}),e.jsx("p",{className:"font-bold truncate mt-0.5",children:u.invoice.employee_name}),e.jsx("p",{className:"text-[10px] text-muted-foreground truncate",children:u.invoice.employee_email})]}),e.jsxs("div",{className:"rounded-xl border border-border/60 p-2.5",children:[e.jsx("p",{className:"text-[10px] uppercase text-muted-foreground font-bold",children:"Sent Date"}),e.jsx("p",{className:"font-bold mt-0.5",children:Pe(u.invoice.sent_at)}),e.jsx("p",{className:"text-[10px] text-muted-foreground",children:"Emailed to staff"})]}),e.jsxs("div",{className:"rounded-xl border border-primary/30 bg-primary/5 p-2.5",children:[e.jsx("p",{className:"text-[10px] uppercase text-primary font-bold",children:"Total"}),e.jsx("p",{className:"font-black text-foreground text-sm mt-0.5",children:y((u.items||[]).reduce((t,s)=>t+(Number(s.amount)||0),0))}),e.jsxs("p",{className:"text-[10px] text-muted-foreground",children:[u.items.length," items"]})]})]}),e.jsx("div",{className:"overflow-hidden rounded-xl border border-border/60",children:e.jsxs("table",{className:"w-full text-left text-xs",children:[e.jsx("thead",{className:"border-b border-border/60 bg-muted/60 text-muted-foreground",children:e.jsxs("tr",{children:[e.jsx("th",{className:"p-2 font-bold",children:"#"}),e.jsx("th",{className:"p-2 font-bold",children:"Code"}),e.jsx("th",{className:"p-2 font-bold",children:"Work Title"}),e.jsx("th",{className:"p-2 text-right font-bold",children:"Amount"})]})}),e.jsx("tbody",{className:"divide-y divide-border/40",children:(u.items||[]).map((t,s)=>e.jsxs("tr",{className:"hover:bg-muted/30",children:[e.jsx("td",{className:"p-2 text-muted-foreground",children:s+1}),e.jsx("td",{className:"p-2 font-mono font-bold",children:t.order_code||"Custom"}),e.jsxs("td",{className:"p-2",children:[e.jsx("span",{className:"font-semibold text-foreground",children:t.title}),t.description&&t.description!=="No additional details"&&e.jsx("p",{className:"text-[10px] text-muted-foreground",children:t.description})]}),e.jsx("td",{className:"p-2 text-right font-bold text-emerald-600 dark:text-emerald-400",children:y(Number(t.amount)||0)})]},t.id))})]})}),u.invoice.notes&&e.jsxs("div",{className:"rounded-xl border border-border/60 p-2.5 text-xs",children:[e.jsx("p",{className:"font-bold text-foreground mb-0.5",children:"Notes"}),e.jsx("p",{className:"text-muted-foreground",children:u.invoice.notes})]}),e.jsxs("div",{className:"flex items-center justify-end gap-2 border-t border-border/50 pt-3",children:[e.jsxs(p,{variant:"outline",size:"sm",onClick:()=>K(Le(u)),className:"h-8 rounded-xl text-xs font-bold",children:[e.jsx(oe,{className:"mr-1.5 h-3.5 w-3.5"}),"Print PDF"]}),e.jsxs(p,{size:"sm",onClick:()=>Se({...u.invoice,item_count:u.items.length,assignment_count:u.items.filter(t=>t.work_assignment_id).length}),className:"h-8 rounded-xl bg-primary text-xs font-bold text-primary-foreground",children:[e.jsx(Ee,{className:"mr-1.5 h-3.5 w-3.5"}),"Resend Email"]})]})]}):e.jsx("div",{className:"py-8 text-center text-xs text-muted-foreground",children:"Invoice details could not be loaded."})]})})]})}export{Ut as default};

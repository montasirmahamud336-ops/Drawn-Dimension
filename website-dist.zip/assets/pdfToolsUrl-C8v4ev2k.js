const n=t=>{const o="https://tools.drawndimension.com";return o.trim()?o.trim():"https://tools.drawndimension.com"};export{n as g};

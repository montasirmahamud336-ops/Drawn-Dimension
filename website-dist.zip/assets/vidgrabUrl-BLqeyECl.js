const e=r=>"https://vidgrab.drawndimension.com";export{e as g};

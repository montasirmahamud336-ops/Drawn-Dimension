import{d as oe,ch as re,g as ae,r as a,j as e,P as ie,a as ne,N as le,O as k,m as C,cs as O,a0 as U,M as ce,S as me,aT as de,A as pe,c as ge,aq as he}from"./index-CRoQ3-QR.js";import{s as xe,a as ue}from"./richText-Ci1ZddZ0.js";import{E as be}from"./ellipsis-DuDIDbBp.js";import{A as V}from"./arrow-up-right-EdWHUMAE.js";/**
 * @license lucide-react v1.14.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]],we=oe("link",fe),J=o=>/^https?:\/\//i.test(o)?o:`https://www.drawndimension.com${o.startsWith("/")?o:`/${o}`}`,I=o=>{if(!o)return"";const n=new Date(o);return Number.isNaN(n.getTime())?"":n.toLocaleDateString(void 0,{year:"numeric",month:"long",day:"numeric"})},L=o=>{if(!o)return null;const n=o.replace(/<[^>]*>/g,"").split(/\s+/).filter(Boolean).length;return`${Math.max(1,Math.ceil(n/220))} min read`},ve=o=>o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"),ye=({className:o})=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:o,children:e.jsx("path",{d:"M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"})}),je=({className:o})=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:o,children:e.jsx("path",{d:"M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"})}),Ne=({className:o})=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor",className:o,children:e.jsx("path",{d:"M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"})}),ke=()=>{const[o,n]=a.useState(0);return a.useEffect(()=>{const t=()=>{const g=document.documentElement,d=g.scrollTop||document.body.scrollTop,b=g.scrollHeight-g.clientHeight;n(b>0?d/b*100:0)};return window.addEventListener("scroll",t,{passive:!0}),()=>window.removeEventListener("scroll",t)},[]),e.jsx("div",{className:"fixed top-0 inset-x-0 z-[60] h-[2px] bg-white/[0.03]",children:e.jsx("div",{className:"h-full bg-gradient-to-r from-primary/70 to-primary transition-[width] duration-150 ease-out",style:{width:`${o}%`}})})},H=({url:o,title:n})=>{const[t,g]=a.useState(!1),d=encodeURIComponent(o),b=encodeURIComponent(n),j=async()=>{try{await navigator.clipboard.writeText(o)}catch{const p=document.createElement("textarea");p.value=o,document.body.appendChild(p),p.select(),document.execCommand("copy"),document.body.removeChild(p)}g(!0),setTimeout(()=>g(!1),2400)},M=async()=>{if(navigator.share)try{await navigator.share({title:n,url:o})}catch{}else j()},S=[{label:"Facebook",icon:e.jsx(ye,{className:"w-[15px] h-[15px]"}),href:`https://www.facebook.com/sharer/sharer.php?u=${d}`,hover:"hover:text-[#1877F2]"},{label:"LinkedIn",icon:e.jsx(je,{className:"w-[15px] h-[15px]"}),href:`https://www.linkedin.com/sharing/share-offsite/?url=${d}`,hover:"hover:text-[#0A66C2]"},{label:"X",icon:e.jsx(Ne,{className:"w-[14px] h-[14px]"}),href:`https://twitter.com/intent/tweet?url=${d}&text=${b}`,hover:"hover:text-white"}];return e.jsxs("div",{className:"flex items-center gap-1",children:[S.map(p=>e.jsx("a",{href:p.href,target:"_blank",rel:"noopener noreferrer",title:`Share on ${p.label}`,className:`w-8 h-8 rounded-full flex items-center justify-center text-white/25 transition-all duration-200 ${p.hover} hover:bg-white/[0.06]`,children:p.icon},p.label)),e.jsx("button",{type:"button",onClick:j,title:t?"Copied":"Copy link",className:`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${t?"text-emerald-400 bg-emerald-400/10":"text-white/25 hover:text-white/60 hover:bg-white/[0.06]"}`,children:t?e.jsx(he,{className:"w-[13px] h-[13px]"}):e.jsx(we,{className:"w-[13px] h-[13px]"})}),"share"in navigator&&e.jsx("button",{type:"button",onClick:M,title:"Share",className:"w-8 h-8 rounded-full flex items-center justify-center text-white/25 hover:text-white/60 hover:bg-white/[0.06] transition-all duration-200",children:e.jsx(V,{className:"w-[13px] h-[13px]"})})]})},Ce=`
/* ── Font import: Inter with all weights ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300..700&display=swap');

/* ── Global text rendering for this block ── */
.blog-prose {
  font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-feature-settings: "cv02", "cv03", "cv04", "cv05", "cv11", "ss01";
  font-variation-settings: "opsz" 32;
  font-size: 17px;
  line-height: 1.78;
  letter-spacing: -0.012em;
  color: rgba(255,255,255,0.80);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
  font-weight: 400;
  text-wrap: pretty;
  -webkit-hyphens: auto;
  hyphens: auto;
  -webkit-hyphenate-character: "­";
}

/* ── Selection ── */
.blog-prose ::selection {
  background: rgba(239,68,68,0.25);
  color: #fff;
}

/* ── Spacing rhythm ── */
.blog-prose > * + * {
  margin-top: 1.55em;
}

/* ── Headings ── */
.blog-prose h2 {
  font-size: 1.55em;
  font-weight: 620;
  letter-spacing: -0.03em;
  line-height: 1.18;
  margin-top: 2.8em;
  margin-bottom: 0.3em;
  color: rgba(255,255,255,0.96);
  font-variation-settings: "opsz" 28;
}

.blog-prose h3 {
  font-size: 1.22em;
  font-weight: 600;
  letter-spacing: -0.02em;
  line-height: 1.25;
  margin-top: 2.4em;
  margin-bottom: 0.2em;
  color: rgba(255,255,255,0.93);
  font-variation-settings: "opsz" 29;
}

.blog-prose h4 {
  font-size: 1.05em;
  font-weight: 600;
  letter-spacing: -0.015em;
  line-height: 1.35;
  margin-top: 2em;
  color: rgba(255,255,255,0.88);
}

/* ── Paragraphs ── */
.blog-prose p {
  margin-top: 1.55em;
  orphans: 2;
  widows: 2;
}

/* ── Lead paragraph (excerpt) ── */
.blog-prose-lead {
  font-family: 'Inter', ui-sans-serif, system-ui, sans-serif;
  font-feature-settings: "cv02", "cv03", "cv04", "cv05", "cv11", "ss01";
  font-variation-settings: "opsz" 34;
  font-size: 20px;
  line-height: 1.65;
  letter-spacing: -0.016em;
  font-weight: 380;
  color: rgba(255,255,255,0.48);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-rendering: optimizeLegibility;
  text-wrap: pretty;
}

/* ── Strong / bold ── */
.blog-prose strong {
  font-weight: 580;
  color: rgba(255,255,255,0.96);
  letter-spacing: -0.008em;
}

/* ── Links ── */
.blog-prose a {
  color: rgba(239,68,68,0.8);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-thickness: 1px;
  text-decoration-color: rgba(239,68,68,0.22);
  transition: color 0.2s ease, text-decoration-color 0.2s ease;
  font-weight: 450;
}
.blog-prose a:hover {
  color: rgba(239,68,68,1);
  text-decoration-color: rgba(239,68,68,0.5);
}

/* ── Lists ── */
.blog-prose ul {
  list-style-type: disc;
  padding-left: 1.35em;
  margin-top: 1.4em;
}
.blog-prose ol {
  list-style-type: decimal;
  padding-left: 1.35em;
  margin-top: 1.4em;
}
.blog-prose li {
  margin-top: 0.4em;
  line-height: 1.72;
  padding-left: 0.15em;
}
.blog-prose li::marker {
  color: rgba(255,255,255,0.15);
  font-size: 0.85em;
}

/* ── Nested lists ── */
.blog-prose li ul,
.blog-prose li ol {
  margin-top: 0.3em;
  margin-bottom: 0;
}

/* ── Blockquote ── */
.blog-prose blockquote {
  border-left: 2.5px solid rgba(239,68,68,0.35);
  padding: 1em 0 1em 1.5em;
  margin: 2em 0 2em 0;
  font-style: normal;
  font-weight: 400;
  color: rgba(255,255,255,0.58);
  background: linear-gradient(100deg, rgba(239,68,68,0.025) 0%, transparent 60%);
  border-radius: 0 0.5rem 0.5rem 0;
  font-size: 1.02em;
  line-height: 1.72;
}
.blog-prose blockquote p {
  margin-top: 0;
}
.blog-prose blockquote p + p {
  margin-top: 1em;
}
.blog-prose blockquote strong {
  color: rgba(255,255,255,0.72);
}

/* ── Horizontal rule ── */
.blog-prose hr {
  border: none;
  height: 1px;
  background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.07) 30%, rgba(255,255,255,0.07) 70%, transparent 100%);
  margin: 3.5em 0;
}

/* ── Images ── */
.blog-prose img {
  border-radius: 0.75rem;
  margin: 2.8em 0;
  max-width: 100%;
  height: auto;
  border: 1px solid rgba(255,255,255,0.04);
  box-shadow: 0 12px 48px -16px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.02) inset;
}

/* ── Figure ── */
.blog-prose figure {
  margin: 2.8em 0;
}
.blog-prose figcaption {
  font-size: 13px;
  line-height: 1.5;
  color: rgba(255,255,255,0.28);
  text-align: center;
  margin-top: 0.75em;
  font-weight: 400;
  letter-spacing: 0.002em;
}

/* ── Inline code ── */
.blog-prose code {
  font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', 'JetBrains Mono', 'Consolas', monospace;
  font-size: 0.86em;
  font-weight: 450;
  background: rgba(255,255,255,0.06);
  padding: 0.12em 0.38em;
  border-radius: 0.3em;
  border: 1px solid rgba(255,255,255,0.04);
  letter-spacing: -0.01em;
  color: rgba(255,255,255,0.85);
}

/* ── Code block ── */
.blog-prose pre {
  font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', 'JetBrains Mono', 'Consolas', monospace;
  font-size: 0.855em;
  line-height: 1.7;
  background: rgba(0,0,0,0.45);
  padding: 1.3em 1.5em;
  border-radius: 0.85rem;
  overflow-x: auto;
  margin: 2em 0;
  border: 1px solid rgba(255,255,255,0.05);
  box-shadow: 0 4px 24px -8px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.02);
  -webkit-overflow-scrolling: touch;
}
.blog-prose pre code {
  background: none;
  padding: 0;
  border: none;
  font-size: 1em;
  color: rgba(255,255,255,0.72);
}

/* ── Tables ── */
.blog-prose table {
  width: 100%;
  border-collapse: collapse;
  margin: 2em 0;
  font-size: 0.92em;
  line-height: 1.55;
}
.blog-prose th {
  background: rgba(255,255,255,0.03);
  font-weight: 550;
  font-size: 0.78em;
  text-transform: uppercase;
  letter-spacing: 0.065em;
  color: rgba(255,255,255,0.45);
  border: 1px solid rgba(255,255,255,0.06);
  padding: 0.7em 1em;
  text-align: left;
}
.blog-prose td {
  border: 1px solid rgba(255,255,255,0.05);
  padding: 0.6em 1em;
  color: rgba(255,255,255,0.72);
  vertical-align: top;
}
.blog-prose tr:hover td {
  background: rgba(255,255,255,0.015);
}

/* ── Edge cases ── */
.blog-prose > :first-child { margin-top: 0; }
.blog-prose > :last-child { margin-bottom: 0; }
.blog-prose > h2:first-child,
.blog-prose > h3:first-child { margin-top: 0; }

/* ── Responsive ── */
@media (max-width: 640px) {
  .blog-prose {
    font-size: 16px;
    line-height: 1.72;
    letter-spacing: -0.01em;
  }
  .blog-prose-lead {
    font-size: 18px;
    line-height: 1.6;
  }
  .blog-prose h2 {
    font-size: 1.4em;
    margin-top: 2.2em;
  }
  .blog-prose h3 {
    font-size: 1.15em;
    margin-top: 1.8em;
  }
  .blog-prose blockquote {
    padding-left: 1.1em;
  }
  .blog-prose img {
    border-radius: 0.5rem;
    margin: 2em 0;
  }
}
`,Se=()=>e.jsxs("div",{className:"animate-pulse",children:[e.jsx("div",{className:"h-4 w-16 rounded bg-white/[0.04] mb-8"}),e.jsx("div",{className:"h-11 w-full rounded bg-white/[0.04]"}),e.jsx("div",{className:"h-11 w-3/4 rounded bg-white/[0.04] mt-3"}),e.jsx("div",{className:"h-5 w-2/5 rounded bg-white/[0.03] mt-6"}),e.jsxs("div",{className:"flex gap-6 mt-5",children:[e.jsx("div",{className:"h-3.5 w-32 rounded bg-white/[0.03]"}),e.jsx("div",{className:"h-3.5 w-20 rounded bg-white/[0.03]"})]}),e.jsx("div",{className:"mt-10 space-y-4",children:Array.from({length:12}).map((o,n)=>e.jsx("div",{className:"h-[20px] rounded bg-white/[0.03]",style:{width:`${80+Math.random()*20}%`}},n))})]}),Ae=()=>{const{slug:o=""}=re(),n=ae(),[t,g]=a.useState(null),[d,b]=a.useState(""),[j,M]=a.useState([]),[S,p]=a.useState(!0),W=a.useRef(null),[w,v]=a.useState([]),[D,P]=a.useState(""),[z,R]=a.useState(""),[X,T]=a.useState(null),[_,E]=a.useState(""),[q,$]=a.useState(null);a.useEffect(()=>{try{const s=localStorage.getItem(`blog-comments-${o}`);if(s){const r=JSON.parse(s);v(Array.isArray(r)?r:[])}else v([])}catch{v([])}},[o]),a.useEffect(()=>{localStorage.setItem(`blog-comments-${o}`,JSON.stringify(w))},[w,o]);const G=s=>{if(s.preventDefault(),!z.trim())return;const r={name:D.trim()||"Anonymous",body:z.trim(),date:new Date().toISOString()};v(l=>[r,...l]),P(""),R("")},Y=s=>{v(r=>r.filter((l,i)=>i!==s)),$(null)},K=s=>{T(s),E(w[s].body),$(null)},Q=()=>{T(null),E("")},Z=s=>{_.trim()&&(v(r=>r.map((l,i)=>i===s?{...l,body:_.trim()}:l)),T(null),E(""))};a.useEffect(()=>{const s=()=>$(null);return document.addEventListener("click",s),()=>document.removeEventListener("click",s)},[]),a.useEffect(()=>{let s=!0;const r=new AbortController;return(async()=>{p(!0);try{const i=await fetch(`${n}/service-blogs?status=live&slug=${encodeURIComponent(o)}&limit=1`,{signal:r.signal});if(!i.ok)throw new Error("fetch failed");const N=await i.json(),x=Array.isArray(N)&&N.length>0?N[0]:null;if(!s)return;g(x);const u=[];x!=null&&x.service_id?(u.push(fetch(`${n}/services?status=live`,{signal:r.signal}).then(m=>m.ok?m.json():[]).then(m=>{if(s&&Array.isArray(m)){const f=m.find(c=>c.id===x.service_id);b((f==null?void 0:f.name)||"")}}).catch(()=>{})),u.push(fetch(`${n}/service-blogs?status=live&service_id=${x.service_id}&limit=5`,{signal:r.signal}).then(m=>m.ok?m.json():[]).then(m=>{s&&Array.isArray(m)&&M(m.filter(f=>f.slug!==o).slice(0,3))}).catch(()=>{}))):s&&b(""),await Promise.allSettled(u)}catch(i){if(r.signal.aborted||!s)return;console.error(i),g(null)}finally{s&&p(!1)}})(),()=>{s=!1,r.abort()}},[n,o]);const A=t?`${t.title} | Drawn Dimension Blog`:"Blog Post | Drawn Dimension",y=(t==null?void 0:t.excerpt)||"Engineering and design insights from Drawn Dimension.",h=J(`/blog/${o}`),ee=a.useMemo(()=>xe((t==null?void 0:t.content)||""),[t==null?void 0:t.content]),B=a.useMemo(()=>ue((t==null?void 0:t.content)||""),[t==null?void 0:t.content]),F=a.useMemo(()=>t?{"@context":"https://schema.org","@type":"BlogPosting",headline:t.title,description:y,datePublished:t.published_at||t.created_at||void 0,image:t.cover_image_url||J("/images/logo.png"),articleBody:B,url:h,publisher:{"@type":"Organization",name:"Drawn Dimension"}}:null,[h,y,B,t]);return a.useEffect(()=>{const s=document.title;document.title=A;const r=(u,m,f)=>{let c=document.head.querySelector(`meta[${u}="${m}"]`);const te=!c;c||(c=document.createElement("meta"),c.setAttribute(u,m),document.head.appendChild(c));const se=c.getAttribute("content")??"";return c.setAttribute("content",f),()=>{te?c==null||c.remove():c==null||c.setAttribute("content",se)}},l=[r("name","description",y),r("property","og:title",A),r("property","og:description",y),r("property","og:type","article"),r("property","og:url",h),r("name","robots","index, follow, max-image-preview:large"),r("name","twitter:card","summary_large_image"),r("name","twitter:title",A),r("name","twitter:description",y)];let i=document.head.querySelector('link[rel="canonical"]');const N=!i;i||(i=document.createElement("link"),i.setAttribute("rel","canonical"),document.head.appendChild(i));const x=i.getAttribute("href")??"";return i.setAttribute("href",h),()=>{document.title=s,l.forEach(u=>u()),N?i==null||i.remove():i==null||i.setAttribute("href",x)}},[h,y,A]),a.useEffect(()=>{const s=window.__lenis;s?(s.scrollTo(0,{immediate:!0}),setTimeout(()=>s.resize(),100)):window.scrollTo(0,0)},[o,S]),e.jsx(ie,{children:e.jsxs(ne,{children:[e.jsx(le,{}),e.jsx("style",{dangerouslySetInnerHTML:{__html:Ce}}),t&&e.jsx(ke,{}),e.jsxs("main",{children:[F&&e.jsx("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify(F)}}),S?e.jsx("div",{className:"pt-32 pb-28",children:e.jsx("div",{className:"max-w-4xl max-w-[680px] px-6",children:e.jsx(Se,{})})}):t?e.jsxs(e.Fragment,{children:[t.cover_image_url?e.jsxs("div",{className:"relative w-full h-[52vh] min-h-[380px] max-h-[580px] overflow-hidden",children:[e.jsx("img",{src:t.cover_image_url,alt:"",className:"absolute inset-0 w-full h-full object-cover scale-105",loading:"eager"}),e.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-[rgba(0,0,0,0.88)] via-[rgba(0,0,0,0.28)] to-[rgba(0,0,0,0.12)]"}),e.jsx("div",{className:"absolute inset-0 bg-gradient-to-r from-[rgba(0,0,0,0.35)] to-transparent"}),e.jsx("div",{className:"absolute inset-0 flex items-end",children:e.jsx("div",{className:"max-auto w-full max-w-4xl px-6 pb-12 md:pb-16",children:e.jsxs(C.div,{initial:{opacity:0,y:28},animate:{opacity:1,y:0},transition:{duration:.7,ease:[.22,1,.36,1]},children:[d&&e.jsx(k,{to:`/blog?service=${d.toLowerCase().replace(/\s+/g,"-")}`,className:"inline-block text-[10px] font-semibold uppercase tracking-[0.18em] text-white/50 border border-white/[0.12] px-2.5 py-[3px] rounded hover:text-white/70 hover:border-white/20 transition-colors",children:d}),e.jsx("h1",{className:"text-[1.75rem] sm:text-[2.15rem] md:text-[2.65rem] lg:text-[2.9rem] font-bold tracking-[-0.035em] leading-[1.1] mt-4 text-white",children:t.title}),e.jsxs("div",{className:"flex flex-wrap items-center gap-x-4 gap-y-2 mt-5",children:[(t.published_at||t.created_at)&&e.jsxs("span",{className:"flex items-center gap-1.5 text-[12.5px] text-white/35",children:[e.jsx(O,{className:"w-3 h-3"}),I(t.published_at||t.created_at)]}),L(t.content)&&e.jsxs("span",{className:"flex items-center gap-1.5 text-[12.5px] text-white/35",children:[e.jsx(U,{className:"w-3 h-3"}),L(t.content)]}),e.jsx("div",{className:"ml-auto",children:e.jsx(H,{url:h,title:t.title})})]})]})})})]}):e.jsx("div",{className:"pt-36 md:pt-44 pb-4",children:e.jsx("div",{className:"mx-auto max-w-5xl px-6",children:e.jsxs(C.div,{initial:{opacity:0,y:28},animate:{opacity:1,y:0},transition:{duration:.7,ease:[.22,1,.36,1]},children:[d&&e.jsx(k,{to:`/blog?service=${d.toLowerCase().replace(/\s+/g,"-")}`,className:"inline-block text-[10px] font-semibold uppercase tracking-[0.18em] text-primary/60 border border-primary/[0.12] px-2.5 py-[3px] rounded hover:text-primary hover:border-primary/25 transition-colors",children:d}),e.jsx("h1",{className:"text-[1.75rem] sm:text-[2.15rem] md:text-[2.65rem] lg:text-[2.9rem] font-bold tracking-[-0.035em] leading-[1.1] mt-5",children:t.title}),e.jsxs("div",{className:"flex flex-wrap items-center gap-x-4 gap-y-2 mt-5 text-muted-foreground",children:[(t.published_at||t.created_at)&&e.jsxs("span",{className:"flex items-center gap-1.5 text-[12.5px]",children:[e.jsx(O,{className:"w-3 h-3 opacity-50"}),I(t.published_at||t.created_at)]}),L(t.content)&&e.jsxs("span",{className:"flex items-center gap-1.5 text-[12.5px]",children:[e.jsx(U,{className:"w-3 h-3 opacity-50"}),L(t.content)]}),e.jsx("div",{className:"ml-auto",children:e.jsx(H,{url:h,title:t.title})})]})]})})}),e.jsxs(C.div,{ref:W,initial:{opacity:0},animate:{opacity:1},transition:{duration:.6,delay:.2},className:"mx-auto max-w-5xl px-6 pt-14 pb-6 md:pt-20",children:[t.excerpt&&e.jsx("p",{className:"blog-prose-lead",style:{marginTop:0},children:t.excerpt}),t.excerpt&&e.jsx("div",{className:"my-10 mx-auto",style:{width:32,height:2,borderRadius:1,background:"rgba(239,68,68,0.25)"}}),e.jsx("div",{className:"blog-prose",dangerouslySetInnerHTML:{__html:ee||`<p>${ve(B||"No content available.")}</p>`}}),e.jsxs("div",{className:"mt-20 pt-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",style:{borderTop:"1px solid rgba(255,255,255,0.04)"},children:[e.jsx("p",{className:"text-[12.5px] text-white/20 tracking-wide",children:"Share this article"}),e.jsx(H,{url:h,title:t.title})]}),e.jsxs("div",{className:"mt-16 pt-10",style:{borderTop:"1px solid rgba(255,255,255,0.06)"},children:[e.jsxs("div",{className:"flex items-center gap-3 mb-8",children:[e.jsx(ce,{className:"w-5 h-5 text-primary/60"}),e.jsxs("h2",{className:"text-lg font-semibold tracking-tight text-white/90",children:["Comments (",w.length,")"]})]}),e.jsxs("form",{onSubmit:G,className:"mb-10 space-y-4",children:[e.jsx("input",{type:"text",placeholder:"Your name (optional)",value:D,onChange:s=>P(s.target.value),maxLength:60,className:"w-full bg-white/[0.03] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white/80 placeholder:text-white/20 focus:outline-none focus:border-primary/40 focus:bg-white/[0.05] transition-colors"}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx("textarea",{placeholder:"Write a comment...",value:z,onChange:s=>R(s.target.value),rows:3,required:!0,className:"flex-1 bg-white/[0.03] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white/80 placeholder:text-white/20 focus:outline-none focus:border-primary/40 focus:bg-white/[0.05] transition-colors resize-none"}),e.jsxs("button",{type:"submit",disabled:!z.trim(),className:"self-end inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-primary/90 hover:bg-primary text-white text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed transition-all",children:[e.jsx(me,{className:"w-4 h-4"}),"Post"]})]})]}),w.length===0?e.jsx("p",{className:"text-sm text-white/25 italic py-4",children:"No comments yet. Be the first to share your thoughts."}):e.jsx("div",{className:"space-y-5",children:w.map((s,r)=>e.jsx(C.div,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},transition:{delay:r*.03},className:"bg-white/[0.02] border border-white/[0.05] rounded-xl p-5 relative",children:X===r?e.jsxs("div",{className:"space-y-3",children:[e.jsx("textarea",{value:_,onChange:l=>E(l.target.value),rows:3,className:"w-full bg-white/[0.05] border border-primary/40 rounded-xl px-4 py-3 text-sm text-white/80 focus:outline-none resize-none"}),e.jsxs("div",{className:"flex justify-end gap-2",children:[e.jsx("button",{onClick:Q,className:"px-4 py-1.5 text-xs font-medium text-white/40 hover:text-white/70 transition-colors",children:"Cancel"}),e.jsx("button",{onClick:()=>Z(r),disabled:!_.trim(),className:"px-4 py-1.5 text-xs font-medium bg-primary/90 hover:bg-primary text-white rounded-lg disabled:opacity-30 transition-all",children:"Save"})]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"flex items-center gap-3 mb-2",children:[e.jsx("span",{className:"inline-flex items-center justify-center w-7 h-7 rounded-full bg-primary/10 text-primary text-xs font-semibold",children:e.jsx(de,{className:"w-3.5 h-3.5"})}),e.jsx("span",{className:"font-medium text-white/80 text-sm",children:s.name}),e.jsx("span",{className:"text-[11px] text-white/25 ml-auto",children:I(s.date)}),e.jsxs("div",{className:"relative",children:[e.jsx("button",{onClick:l=>{l.stopPropagation(),$(q===r?null:r)},className:"w-7 h-7 flex items-center justify-center rounded-full text-white/25 hover:text-white/60 hover:bg-white/[0.05] transition-colors",children:e.jsx(be,{className:"w-4 h-4"})}),q===r&&e.jsxs("div",{className:"absolute right-0 top-full mt-1 w-28 bg-[#1a1a1a] border border-white/[0.1] rounded-lg shadow-xl z-20 overflow-hidden",children:[e.jsx("button",{onClick:l=>{l.stopPropagation(),K(r)},className:"w-full text-left px-3 py-2 text-xs text-white/70 hover:bg-white/[0.05] transition-colors",children:"Edit"}),e.jsx("button",{onClick:l=>{l.stopPropagation(),Y(r)},className:"w-full text-left px-3 py-2 text-xs text-red-400 hover:bg-white/[0.05] transition-colors",children:"Delete"})]})]})]}),e.jsx("p",{className:"text-sm text-white/60 leading-relaxed pl-10",children:s.body})]})},r))})]})]}),j.length>0&&e.jsx("section",{className:"border-t border-white/[0.03]",children:e.jsxs("div",{className:"mx-auto max-w-[1060px] px-6 py-20 md:py-28",children:[e.jsxs(C.div,{initial:{opacity:0,y:16},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.5},children:[e.jsx("p",{className:"text-[10px] font-semibold uppercase tracking-[0.18em] text-primary/40 mb-2",children:d||"More"}),e.jsx("h2",{className:"text-[1.5rem] md:text-[1.75rem] font-bold tracking-[-0.03em]",children:"Continue reading"})]}),e.jsx("div",{className:"grid md:grid-cols-3 gap-0 mt-10 border border-white/[0.04] rounded-xl overflow-hidden",children:j.map((s,r)=>e.jsxs(k,{to:`/blog/${s.slug}`,className:`group relative block overflow-hidden bg-white/[0.008] hover:bg-white/[0.025] transition-colors duration-300 ${r>0?"md:border-l border-white/[0.04]":""}`,children:[e.jsxs("div",{className:"relative aspect-[4/3] overflow-hidden",children:[s.cover_image_url?e.jsx("img",{src:s.cover_image_url,alt:"",className:"absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.06]",loading:"lazy"}):e.jsx("div",{className:"absolute inset-0 bg-gradient-to-br from-primary/[0.05] to-transparent"}),e.jsx("div",{className:"absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/35 to-transparent"})]}),e.jsxs("div",{className:"p-5 md:p-6",children:[e.jsx("span",{className:"text-[10px] font-medium uppercase tracking-[0.12em] text-white/18",children:I(s.published_at||s.created_at)}),e.jsx("h3",{className:"text-[14.5px] md:text-[15px] font-semibold leading-snug mt-2 text-foreground/75 group-hover:text-foreground transition-colors line-clamp-2 tracking-[-0.01em]",children:s.title}),e.jsxs("span",{className:"inline-flex items-center gap-1 text-[11.5px] font-medium text-primary/50 mt-3 group-hover:text-primary/80 transition-colors",children:["Read",e.jsx(V,{className:"w-2.5 h-2.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"})]})]})]},s.id))}),e.jsxs(k,{to:"/blog",className:"inline-flex items-center gap-1.5 text-[12.5px] font-medium text-white/20 hover:text-white/50 mt-8 transition-colors",children:[e.jsx(pe,{className:"w-3 h-3"}),"All articles"]})]})})]}):e.jsxs("div",{className:"flex flex-col items-center justify-center min-h-[80vh] text-center px-6",children:[e.jsx("p",{className:"text-7xl font-bold tracking-tighter text-white/[0.05]",children:"404"}),e.jsx("h1",{className:"text-xl font-semibold mt-2 tracking-tight",children:"Article not found"}),e.jsx("p",{className:"text-sm text-muted-foreground mt-2 max-w-xs leading-relaxed",children:"This post may have been moved or removed."}),e.jsx(k,{to:"/blog",className:"mt-7 text-sm font-medium text-primary hover:text-primary/80 transition-colors",children:"← Back to blog"})]})]}),e.jsx(ge,{})]})})};export{Ae as default};

import{j as e}from"./vendor-radix-Phst1WNl.js";import{D as m}from"./homePageSettings-Co3sqpA7.js";import{r as c}from"./mediaUrl-5nh1MolG.js";const g=({data:i})=>{const a=i??m.sections["trusted-logos"],t=a.logos.filter(r=>r.image_url);return t.length===0?null:e.jsxs("section",{id:"trusted-logos",className:"relative overflow-hidden py-12 md:py-16",children:[e.jsx("div",{className:"container-narrow relative z-10",children:e.jsxs("div",{className:"mx-auto mb-12 max-w-3xl text-center",children:[e.jsxs("span",{className:"inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-primary",children:[e.jsx("span",{className:"h-1.5 w-1.5 rounded-full bg-primary animate-pulse"}),a.badge]}),e.jsx("h2",{className:"mt-5 text-3xl font-extrabold tracking-tight text-foreground md:text-4xl",children:a.title}),e.jsx("p",{className:"mt-4 text-base leading-relaxed text-muted-foreground md:text-lg",children:a.description})]})}),e.jsxs("div",{className:"relative",children:[e.jsx("div",{className:"pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-background to-transparent"}),e.jsx("div",{className:"pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-background to-transparent"}),e.jsx("div",{className:"overflow-hidden marquee-container group",children:e.jsx("div",{className:"marquee-track inline-flex items-center",style:{animationDuration:`${t.length*7}s`},children:[...t,...t].map((r,n)=>{const l=c(r.image_url),s=e.jsx("img",{src:l,alt:r.name,loading:n<t.length?"eager":"lazy",decoding:"async",onError:o=>{o.currentTarget.style.display="none"},className:"h-20 w-auto object-contain opacity-80 transition-opacity duration-300 hover:opacity-100 md:h-28"});return r.link?e.jsx("a",{href:r.link,target:"_blank",rel:"noreferrer",className:"inline-block px-6 md:px-8 shrink-0","aria-label":r.name,children:s},`${r.id}-${n}`):e.jsx("span",{className:"inline-block px-6 md:px-8 shrink-0",children:s},`${r.id}-${n}`)})})})]}),e.jsx("style",{children:`
        .marquee-track {
          animation: marqueeScroll linear infinite;
        }
        .marquee-container:hover .marquee-track {
          animation-play-state: paused;
        }
        @keyframes marqueeScroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
      `})]})};export{g as default};

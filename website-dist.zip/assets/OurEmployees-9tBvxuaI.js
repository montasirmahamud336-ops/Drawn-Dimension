import{j as e,c8 as t}from"./index-CRoQ3-QR.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

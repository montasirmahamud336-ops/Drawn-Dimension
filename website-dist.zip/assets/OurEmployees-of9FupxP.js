import{j as e,c8 as t}from"./index-CMEqReyE.js";const a=()=>e.jsx(t,{to:"/team",replace:!0});export{a as default};

const o=["WordPress Website","E-commerce Website","Portfolio Website","Realstate Website","Python Tools"],s=o.filter(e=>e!=="Python Tools");export{o as P,s as W};

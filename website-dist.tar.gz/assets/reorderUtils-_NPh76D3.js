import{l}from"./index-C7I15ZXT.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=l("GripVertical",[["circle",{cx:"9",cy:"12",r:"1",key:"1vctgf"}],["circle",{cx:"9",cy:"5",r:"1",key:"hp0tcf"}],["circle",{cx:"9",cy:"19",r:"1",key:"fkjjf6"}],["circle",{cx:"15",cy:"12",r:"1",key:"1tmaij"}],["circle",{cx:"15",cy:"5",r:"1",key:"19l28e"}],["circle",{cx:"15",cy:"19",r:"1",key:"f4zoj3"}]]),d=(c,t,o)=>{if(t===o)return c;const e=c.findIndex(n=>n.id===t),r=c.findIndex(n=>n.id===o);if(e<0||r<0||e===r)return c;const i=[...c],[y]=i.splice(e,1);return i.splice(r,0,y),i};export{f as G,d as m};

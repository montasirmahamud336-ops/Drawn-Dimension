import { Router, Request, Response } from "express";
import Stripe from "stripe";
import { env } from "../config/env.js";

const router = Router();

const getStripeInstance = () => {
  const secretKey = env.stripeSecretKey;
  if (!secretKey) {
    throw new Error("Stripe secret key is not configured on the server");
  }
  return new Stripe(secretKey, {
    apiVersion: "2025-02-24.acacia" as unknown as Stripe.LatestApiVersion,
  });
};

// Helper: Parse price string (e.g. "$499/mo", "$1,200", "500", "BDT 15,000") to integer cents
const parseAmountToCents = (priceInput: string | number, currency = "usd"): number => {
  if (typeof priceInput === "number") {
    return Math.round(priceInput * 100);
  }

  const clean = String(priceInput || "")
    .replace(/[^0-9.]/g, "")
    .trim();
  const numeric = parseFloat(clean);
  if (!Number.isFinite(numeric) || numeric <= 0) {
    return 1000; // default fallback $10.00
  }

  return Math.round(numeric * 100);
};

// 1. GET /api/payments/config - Public publishable key for client
router.get("/api/payments/config", (_req: Request, res: Response) => {
  return res.json({
    publishableKey: env.stripePublishableKey || "",
    isConfigured: Boolean(env.stripeSecretKey && env.stripePublishableKey),
  });
});

// 2. POST /api/payments/create-payment-intent (For Inline Card & Digital Wallet Checkout)
router.post("/api/payments/create-payment-intent", async (req: Request, res: Response) => {
  try {
    const stripe = getStripeInstance();
    const {
      planName = "Service Package",
      price = 100,
      currency = "usd",
      customerEmail,
      customerName,
      metadata = {},
    } = req.body ?? {};

    const amountInCents = parseAmountToCents(price, currency);
    const normalizedCurrency = String(currency).toLowerCase() || "usd";

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency: normalizedCurrency,
      automatic_payment_methods: {
        enabled: true,
      },
      receipt_email: customerEmail ? String(customerEmail).trim() : undefined,
      description: `Drawn Dimension - ${planName}`,
      metadata: {
        ...metadata,
        customerName: customerName || "",
        customerEmail: customerEmail || "",
        planName,
      },
    });

    return res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
      amount: paymentIntent.amount / 100,
      currency: paymentIntent.currency.toUpperCase(),
    });
  } catch (error: unknown) {
    console.error("Stripe create-payment-intent error:", error);
    return res.status(500).json({
      message: error instanceof Error ? error.message : "Failed to create payment intent",
    });
  }
});

// 3. POST /api/payments/create-checkout-session (For Stripe Hosted Redirect)
router.post("/api/payments/create-checkout-session", async (req: Request, res: Response) => {
  try {
    const stripe = getStripeInstance();
    const {
      planName = "Service Plan",
      description = "Drawn Dimension Engineering & Digital Innovation Services",
      price = 100,
      currency = "usd",
      customerEmail,
      customerName,
      successUrl,
      cancelUrl,
      metadata = {},
    } = req.body ?? {};

    const amountInCents = parseAmountToCents(price, currency);
    const normalizedCurrency = String(currency).toLowerCase() || "usd";

    const origin = req.headers.origin || env.siteBaseUrl || "http://localhost:8080";
    const defaultSuccessUrl = `${origin}/payment?status=success&session_id={CHECKOUT_SESSION_ID}&plan=${encodeURIComponent(
      planName
    )}`;
    const defaultCancelUrl = `${origin}/payment?status=cancelled&plan=${encodeURIComponent(planName)}`;

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: normalizedCurrency,
            product_data: {
              name: planName,
              description: description,
              images: env.brandLogoUrl ? [env.brandLogoUrl] : [],
            },
            unit_amount: amountInCents,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      customer_email: customerEmail ? String(customerEmail).trim() : undefined,
      success_url: successUrl || defaultSuccessUrl,
      cancel_url: cancelUrl || defaultCancelUrl,
      metadata: {
        ...metadata,
        customerName: customerName || "",
        planName,
      },
    });

    return res.json({
      sessionId: session.id,
      url: session.url,
    });
  } catch (error: unknown) {
    console.error("Stripe create-checkout-session error:", error);
    return res.status(500).json({
      message: error instanceof Error ? error.message : "Failed to create Stripe checkout session",
    });
  }
});

// 4. GET /api/payments/verify-session
router.get("/api/payments/verify-session", async (req: Request, res: Response) => {
  try {
    const sessionId = String(req.query.session_id || "").trim();
    if (!sessionId) {
      return res.status(400).json({ message: "session_id query parameter is required" });
    }

    const stripe = getStripeInstance();
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["payment_intent", "line_items"],
    });

    const isPaid = session.payment_status === "paid";
    const amountTotal = (session.amount_total ?? 0) / 100;

    return res.json({
      id: session.id,
      paymentStatus: session.payment_status,
      isPaid,
      amountTotal,
      currency: (session.currency ?? "usd").toUpperCase(),
      customerEmail: session.customer_details?.email ?? session.customer_email ?? "",
      customerName: session.customer_details?.name ?? session.metadata?.customerName ?? "",
      planName: session.metadata?.planName ?? "Service Plan",
      created: session.created ? new Date(session.created * 1000).toISOString() : new Date().toISOString(),
    });
  } catch (error: unknown) {
    console.error("Stripe verify-session error:", error);
    return res.status(500).json({
      message: error instanceof Error ? error.message : "Failed to verify session",
    });
  }
});

// 5. GET /api/payments/verify-payment-intent
router.get("/api/payments/verify-payment-intent", async (req: Request, res: Response) => {
  try {
    const intentId = String(req.query.intent_id || "").trim();
    if (!intentId) {
      return res.status(400).json({ message: "intent_id query parameter is required" });
    }

    const stripe = getStripeInstance();
    const intent = await stripe.paymentIntents.retrieve(intentId);

    const isPaid = intent.status === "succeeded";
    const amountTotal = (intent.amount ?? 0) / 100;

    return res.json({
      id: intent.id,
      paymentStatus: intent.status,
      isPaid,
      amountTotal,
      currency: (intent.currency ?? "usd").toUpperCase(),
      customerEmail: intent.receipt_email ?? intent.metadata?.customerEmail ?? "",
      customerName: intent.metadata?.customerName ?? "",
      planName: intent.metadata?.planName ?? "Service Plan",
      created: intent.created ? new Date(intent.created * 1000).toISOString() : new Date().toISOString(),
    });
  } catch (error: unknown) {
    console.error("Stripe verify-payment-intent error:", error);
    return res.status(500).json({
      message: error instanceof Error ? error.message : "Failed to verify payment intent",
    });
  }
});

export default router;
